import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { disclaimer, firm, logo, whatsappLink } from "@/data/site";

const nav = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/training", label: "Training" },
  { to: "/audits", label: "Audits" },
  { to: "/clients", label: "Clients" },
  { to: "/contact", label: "Contact" },
] as const;

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <div className="min-h-screen bg-bg text-ink">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:rounded-full focus:bg-surface focus:px-4 focus:py-2"
      >
        Skip to content
      </a>
      <div className="sticky top-0 z-40">
        <div className="bg-ink text-on-ink">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-6 gap-y-1 px-5 py-2 text-sm">
            <p className="min-w-0 truncate">Free consultation open until 10 Dec 2026</p>
            <Link
              to="/contact"
              search={{ service: firm.offer }}
              className="inline-flex min-h-11 shrink-0 items-center gap-1 font-semibold"
            >
              Book
              <ArrowUpRight className="size-4" aria-hidden />
            </Link>
          </div>
        </div>
        <header className="border-b border-line bg-bg/95 backdrop-blur-md">
          <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5">
            <Link to="/" className="flex min-w-0 items-center gap-3">
              <img
                src={logo}
                alt=""
                width={44}
                height={44}
                className="size-11 shrink-0 rounded-full object-cover"
              />
              <span className="min-w-0 leading-tight">
                <span className="block truncate font-display text-base font-semibold">Shubhkiran</span>
                <span className="block truncate text-xs font-medium text-muted">Quality Forum · Nashik</span>
              </span>
            </Link>
            <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
              {nav.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={`rounded-full px-3 py-2 text-sm font-semibold ${
                    pathname === item.to ? "bg-ink text-on-ink" : "text-muted hover:text-ink"
                  }`}
                  current={pathname === item.to}
                >
                  {item.label}
                </NavLink>
              ))}
            </nav>
            <div className="flex items-center gap-2">
              <Link
                to="/contact"
                className="hidden min-h-11 items-center rounded-full bg-accent px-4 text-sm font-semibold text-on-accent sm:inline-flex"
              >
                Talk to SQF
              </Link>
              <button
                type="button"
                className="inline-flex size-11 items-center justify-center rounded-full border border-line bg-surface lg:hidden"
                aria-expanded={open}
                aria-controls="mobile-nav"
                onClick={() => setOpen((value) => !value)}
              >
                {open ? <X className="size-5" /> : <Menu className="size-5" />}
                <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
              </button>
            </div>
          </div>
          {open ? (
            <nav id="mobile-nav" className="border-t border-line bg-bg px-5 py-2 lg:hidden" aria-label="Mobile">
              {nav.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className="block border-b border-line py-3 font-display text-2xl font-semibold"
                >
                  {item.label}
                </NavLink>
              ))}
            </nav>
          ) : null}
        </header>
      </div>
      <main id="main">{children}</main>
      <footer className="mt-8 bg-ink text-on-ink">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-12">
          <div className="md:col-span-5">
            <div className="flex items-center gap-3">
              <img src={logo} alt="" width={48} height={48} className="size-12 rounded-full object-cover" />
              <p className="font-display text-xl font-semibold">{firm.name}</p>
            </div>
            <p className="mt-4 max-w-sm text-sm text-on-ink/80">
              Consultancy, training and audit readiness. Nashik, since {firm.established}.
            </p>
            <p className="mt-4 max-w-sm text-sm text-on-ink/80">{firm.address}</p>
          </div>
          <div className="md:col-span-3">
            <p className="text-xs font-semibold tracking-widest text-on-ink/60">VISIT</p>
            <ul className="mt-3 space-y-2 text-sm">
              {nav.map((item) => (
                <li key={item.to}>
                  <NavLink to={item.to} className="hover:underline">
                    {item.label}
                  </NavLink>
                </li>
              ))}
              <li>
                <a href={firm.profile} className="hover:underline">
                  Company profile (PDF)
                </a>
              </li>
            </ul>
          </div>
          <div className="md:col-span-4">
            <p className="text-xs font-semibold tracking-widest text-on-ink/60">TALK</p>
            <ul className="mt-3 space-y-2 text-sm">
              {firm.phones.map((phone) => (
                <li key={phone.tel}>
                  <a href={`tel:${phone.tel}`} className="hover:underline">
                    {phone.display}
                    <span className="text-on-ink/60"> · {phone.label}</span>
                  </a>
                </li>
              ))}
              <li>
                <a
                  href={whatsappLink("Hello SQF, I would like to connect.")}
                  className="hover:underline"
                >
                  WhatsApp · {firm.whatsappDisplay}
                </a>
              </li>
              {firm.emails.map((email) => (
                <li key={email}>
                  <a href={`mailto:${email}`} className="hover:underline">
                    {email}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="border-t border-on-ink/15">
          <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-xs text-on-ink/70 md:flex-row md:items-center md:justify-between">
            <p>© {new Date().getFullYear()} {firm.name}. All rights reserved.</p>
            <p className="max-w-xl">{disclaimer}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export function Kicker({ children, onDark = false }: { children: React.ReactNode; onDark?: boolean }) {
  return (
    <p className={`text-xs font-semibold tracking-widest uppercase ${onDark ? "text-on-ink/70" : "text-muted"}`}>
      {children}
    </p>
  );
}

function NavLink({
  to,
  className,
  current,
  children,
}: {
  to: (typeof nav)[number]["to"];
  className?: string;
  current?: boolean;
  children: React.ReactNode;
}) {
  if (to === "/contact") {
    return (
      <Link to="/contact" className={className} aria-current={current ? "page" : undefined}>
        {children}
      </Link>
    );
  }
  return (
    <Link to={to} className={className} aria-current={current ? "page" : undefined}>
      {children}
    </Link>
  );
}

export function PageIntro({
  kicker,
  title,
  lede,
  actions,
}: {
  kicker: string;
  title: React.ReactNode;
  lede: string;
  actions?: React.ReactNode;
}) {
  return (
    <header className="mx-auto max-w-6xl px-5 pt-14 pb-10 md:pt-20">
      <Kicker>{kicker}</Kicker>
      <h1 className="mt-3 max-w-3xl font-display text-4xl font-semibold leading-tight sm:text-5xl">
        {title}
      </h1>
      <p className="mt-4 max-w-2xl text-lg text-muted">{lede}</p>
      {actions ? <div className="mt-6 flex flex-wrap gap-3">{actions}</div> : null}
    </header>
  );
}

export function ContactButton({
  service = "",
  children,
  tone = "accent",
}: {
  service?: string;
  children: React.ReactNode;
  tone?: "accent" | "ink";
}) {
  const className = `inline-flex min-h-11 items-center gap-2 rounded-full px-5 text-sm font-semibold ${
    tone === "ink" ? "bg-ink text-on-ink" : "bg-accent text-on-accent"
  }`;
  if (!service) {
    return (
      <Link to="/contact" className={className}>
        {children}
        <ArrowUpRight className="size-4" aria-hidden />
      </Link>
    );
  }
  return (
    <Link to="/contact" search={{ service }} className={className}>
      {children}
      <ArrowUpRight className="size-4" aria-hidden />
    </Link>
  );
}

export function GhostLink({ href, children }: { href: string; children: React.ReactNode }) {
  const className =
    "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-5 text-sm font-semibold";
  if (href === "/contact") {
    return (
      <Link to="/contact" className={className}>
        {children}
      </Link>
    );
  }
  if (href === "/services") {
    return (
      <Link to="/services" className={className}>
        {children}
      </Link>
    );
  }
  if (href === "/" || href === "/about" || href === "/training" || href === "/audits" || href === "/clients") {
    return (
      <Link to={href} className={className}>
        {children}
      </Link>
    );
  }
  return (
    <a href={href} className={className}>
      {children}
    </a>
  );
}

export function CloseBand() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <div className="flex flex-col gap-6 rounded-card bg-surface p-8 ring-1 ring-line md:flex-row md:items-end md:justify-between md:p-10">
        <div>
          <Kicker>Next step</Kicker>
          <h2 className="mt-2 font-display text-3xl font-semibold leading-tight sm:text-4xl">
            Tell us the standard.
            <span className="block">We’ll talk through the scope.</span>
          </h2>
        </div>
        <div className="flex flex-wrap gap-3">
          <ContactButton>Talk to SQF</ContactButton>
          <GhostLink href={whatsappLink("Hello SQF, I would like to connect.")}>
            WhatsApp
          </GhostLink>
        </div>
      </div>
    </section>
  );
}
