import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { gallery } from "@/data/site";

export function PhotoGrid() {
  const [index, setIndex] = useState<number | null>(null);

  useEffect(() => {
    if (index === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setIndex(null);
      if (event.key === "ArrowRight") setIndex((i) => (i === null ? i : (i + 1) % gallery.length));
      if (event.key === "ArrowLeft")
        setIndex((i) => (i === null ? i : (i - 1 + gallery.length) % gallery.length));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [index]);

  return (
    <>
      <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {gallery.map((photo, photoIndex) => (
          <li key={photo.src} className={photoIndex === 0 ? "sm:col-span-2 lg:col-span-2" : ""}>
            <button
              type="button"
              className="group block w-full overflow-hidden rounded-card bg-surface text-left ring-1 ring-line"
              onClick={() => setIndex(photoIndex)}
            >
              <img
                src={photo.src}
                alt={photo.alt}
                className="aspect-[4/3] w-full object-cover motion-safe:transition motion-safe:group-hover:scale-105"
              />
              <span className="block px-4 py-3 text-sm font-semibold">{photo.caption}</span>
            </button>
          </li>
        ))}
      </ul>
      {index !== null ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-ink/90 p-4"
          role="dialog"
          aria-modal="true"
          aria-label={gallery[index].caption}
          onClick={() => setIndex(null)}
        >
          <div className="w-full max-w-4xl" onClick={(event) => event.stopPropagation()}>
            <img
              src={gallery[index].src}
              alt={gallery[index].alt}
              className="max-h-[75vh] w-full rounded-card object-contain"
            />
            <div className="mt-3 flex items-center justify-between gap-3 text-on-ink">
              <p className="font-semibold">{gallery[index].caption}</p>
              <div className="flex gap-2">
                <button
                  type="button"
                  className="inline-flex size-11 items-center justify-center rounded-full bg-on-ink text-ink"
                  aria-label="Previous photograph"
                  onClick={() => setIndex((i) => (i === null ? i : (i - 1 + gallery.length) % gallery.length))}
                >
                  <ChevronLeft className="size-5" />
                </button>
                <button
                  type="button"
                  className="inline-flex size-11 items-center justify-center rounded-full bg-on-ink text-ink"
                  aria-label="Next photograph"
                  onClick={() => setIndex((i) => (i === null ? i : (i + 1) % gallery.length))}
                >
                  <ChevronRight className="size-5" />
                </button>
                <button
                  type="button"
                  className="inline-flex size-11 items-center justify-center rounded-full bg-on-ink text-ink"
                  aria-label="Close"
                  onClick={() => setIndex(null)}
                >
                  <X className="size-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
