import { useState } from "react";
import { firm, interestOptions } from "@/data/site";

type Delivery = "email" | "whatsapp";

export function EnquiryForm({ initialService = "" }: { initialService?: string }) {
  const known = interestOptions.includes(initialService as (typeof interestOptions)[number]);
  const options = known || !initialService ? interestOptions : [initialService, ...interestOptions];
  const [service, setService] = useState(initialService || "ISO 9001");
  const [delivery, setDelivery] = useState<Delivery>("whatsapp");
  const [status, setStatus] = useState("");

  function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get("name") ?? "").trim();
    const company = String(data.get("company") ?? "").trim();
    const message = String(data.get("message") ?? "").trim();
    const chosen = String(data.get("service") ?? service);
    const body = [
      "Hello SQF,",
      "",
      `Name: ${name}`,
      `Company: ${company}`,
      `Interested in: ${chosen}`,
      "",
      message,
    ].join("\n");

    if (delivery === "whatsapp") {
      const url = `https://wa.me/${firm.whatsapp}?text=${encodeURIComponent(body)}`;
      setStatus("Opening WhatsApp with your message. Nothing is stored on this website.");
      window.location.assign(url);
      return;
    }

    const url = `mailto:${firm.emails[0]}?subject=${encodeURIComponent(
      `SQF enquiry — ${chosen}`,
    )}&body=${encodeURIComponent(body)}`;
    setStatus("Opening your email app with a prepared message. Nothing is stored on this website.");
    window.location.assign(url);
  }

  return (
    <form id="enquiry-form" onSubmit={onSubmit} className="rounded-card bg-surface p-5 ring-1 ring-line sm:p-7">
      <h2 className="font-display text-2xl font-semibold">How can we help?</h2>
      <p className="mt-1 text-sm text-muted">
        Share a few details. You review and send the message yourself.
      </p>
      <div className="mt-5 grid gap-4">
        <Field label="Your name" id="name">
          <input id="name" name="name" required autoComplete="name" className={inputClass} />
        </Field>
        <Field label="Company" id="company">
          <input id="company" name="company" required autoComplete="organization" className={inputClass} />
        </Field>
        <Field label="I’m interested in" id="service">
          <select
            id="service"
            name="service"
            value={service}
            onChange={(event) => setService(event.target.value)}
            className={inputClass}
          >
            {options.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Your requirements" id="message">
          <textarea id="message" name="message" required rows={5} className={`${inputClass} h-auto py-3`} />
        </Field>
      </div>
      <fieldset className="mt-4">
        <legend className="text-sm font-semibold">Send using</legend>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <DeliveryOption
            checked={delivery === "whatsapp"}
            onChange={() => setDelivery("whatsapp")}
            label="WhatsApp"
            value="whatsapp"
          />
          <DeliveryOption
            checked={delivery === "email"}
            onChange={() => setDelivery("email")}
            label="Email"
            value="email"
          />
        </div>
      </fieldset>
      <button
        type="submit"
        className="mt-5 inline-flex min-h-12 w-full items-center justify-center rounded-full bg-accent px-5 font-semibold text-on-accent"
      >
        {delivery === "whatsapp" ? "Prepare WhatsApp enquiry" : "Prepare email enquiry"}
      </button>
      <p className="mt-3 text-sm text-muted" role="status">
        {status ||
          (delivery === "whatsapp"
            ? "Opens WhatsApp with a prepared message. This website does not store your enquiry."
            : "Opens your email app with a prepared message. This website does not store your enquiry.")}
      </p>
    </form>
  );
}

const inputClass =
  "h-12 w-full rounded-2xl border border-line bg-bg px-4 text-base outline-none";

function Field({
  label,
  id,
  children,
}: {
  label: string;
  id: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block text-sm font-semibold" htmlFor={id}>
      {label}
      <span className="mt-2 block font-normal">{children}</span>
    </label>
  );
}

function DeliveryOption({
  checked,
  onChange,
  label,
  value,
}: {
  checked: boolean;
  onChange: () => void;
  label: string;
  value: string;
}) {
  return (
    <label
      className={`flex min-h-11 cursor-pointer items-center justify-center rounded-full border text-sm font-semibold ${
        checked ? "border-ink bg-ink text-on-ink" : "border-line bg-bg"
      }`}
    >
      <input className="sr-only" type="radio" name="delivery" value={value} checked={checked} onChange={onChange} />
      {label}
    </label>
  );
}
