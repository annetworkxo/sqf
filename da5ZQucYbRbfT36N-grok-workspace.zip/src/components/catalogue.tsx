import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Search } from "lucide-react";
import { areas, services, type Area } from "@/data/site";

export function Catalogue({ initialQuery = "", initialArea = "all" }: { initialQuery?: string; initialArea?: string }) {
  const [query, setQuery] = useState(initialQuery);
  const [area, setArea] = useState<Area | "all">(
    areas.includes(initialArea as Area) ? (initialArea as Area) : "all",
  );

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return services.filter((service) => {
      if (area !== "all" && service.area !== area) return false;
      if (!q) return true;
      return `${service.code} ${service.title} ${service.summary} ${service.area}`
        .toLowerCase()
        .includes(q);
    });
  }, [query, area]);

  return (
    <div>
      <div className="rounded-card bg-surface p-4 ring-1 ring-line sm:p-5">
        <label className="block text-sm font-semibold" htmlFor="catalogue-search">
          Search the catalogue
        </label>
        <div className="mt-2 flex items-center gap-2 rounded-full border border-line bg-bg px-4">
          <Search className="size-4 text-muted" aria-hidden />
          <input
            id="catalogue-search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="ISO 9001, IATF, food safety, BIS…"
            className="h-12 w-full bg-transparent text-base outline-none placeholder:text-muted"
          />
        </div>
        <div className="mt-4 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Service area">
          <Chip active={area === "all"} onClick={() => setArea("all")}>
            All
          </Chip>
          {areas.map((item) => (
            <Chip key={item} active={area === item} onClick={() => setArea(item)}>
              {item}
            </Chip>
          ))}
        </div>
      </div>
      <p className="mt-5 text-sm text-muted">
        {results.length} {results.length === 1 ? "service" : "services"}
      </p>
      {results.length === 0 ? (
        <div className="mt-4 rounded-card border border-dashed border-line bg-surface p-8">
          <p className="font-display text-2xl font-semibold">Nothing matches that yet.</p>
          <p className="mt-2 text-muted">
            Try another term, or ask SQF to confirm the scope for your organization.
          </p>
          <Link
            to="/contact"
            search={{ service: query.slice(0, 120) || "Other enquiry" }}
            className="mt-4 inline-flex min-h-11 items-center gap-2 font-semibold text-accent"
          >
            Ask about this requirement
            <ArrowUpRight className="size-4" aria-hidden />
          </Link>
        </div>
      ) : (
        <ul className="mt-4 grid gap-3 sm:grid-cols-2">
          {results.map((service) => (
            <li key={service.code} className="rounded-card bg-surface p-5 ring-1 ring-line">
              <p className="text-xs font-semibold tracking-wide text-accent">{service.area}</p>
              <h3 className="mt-2 font-display text-2xl font-semibold">{service.code}</h3>
              <p className="mt-1 font-medium">{service.title}</p>
              <p className="mt-2 text-sm text-muted">{service.summary}</p>
              <Link
                to="/contact"
                search={{ service: service.code }}
                className="mt-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold"
              >
                Enquire
                <ArrowUpRight className="size-4" aria-hidden />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      onClick={onClick}
      className={`shrink-0 rounded-full px-3 py-2 text-sm font-semibold ${
        active ? "bg-ink text-on-ink" : "bg-bg text-muted"
      }`}
    >
      {children}
    </button>
  );
}
