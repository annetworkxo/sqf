export const firm = {
  name: "Shubhkiran Quality Forum",
  short: "SQF",
  city: "Nashik, Maharashtra",
  established: 1999,
  tagline: "Better systems. Stronger teams. Lasting quality.",
  lede: "Quality goes beyond a certificate. We help you build practical management systems, prepare for audits, and give your people the skills to keep improving.",
  leader: "Mr. Vilas Shinde",
  leaderRole: "Mechanical engineer and lead auditor",
  address:
    "Flat No. 1105, Wing B, Harivishwa Apartment, Khanderao Nagar, Behind Express In Hotel, Pathardi Phata, Nashik – 422010, Maharashtra",
  map: "https://www.google.com/maps/search/?api=1&query=Harivishwa+Apartment+Pathardi+Phata+Nashik+422010",
  emails: ["shubhkiranquality@gmail.com", "vishwaqc@gmail.com"],
  whatsapp: "917875556748",
  whatsappDisplay: "+91 78755 56748",
  phones: [
    { label: "Vilas Shinde", display: "+91 93703 17764", tel: "+919370317764" },
    { label: "Mobile", display: "+91 78755 56741", tel: "+917875556741" },
    { label: "Office", display: "0253 2380070", tel: "+912532380070" },
  ],
  profile: "/assets/documents/sqf-company-profile.pdf",
  offer: "Free consultation",
  offerWindow: "10 November – 10 December 2026",
} as const;

export const logo = "/assets/images/sqf-logo-mark.png";

export const standards = [
  { code: "ISO 9001", label: "Quality" },
  { code: "IATF 16949", label: "Automotive" },
  { code: "ISO 14001", label: "Environment" },
  { code: "ISO 45001", label: "Health & safety" },
  { code: "ISO 22000", label: "Food safety" },
] as const;

export const homeStats = [
  { value: "20+", label: "Technical experts" },
  { value: "~30", label: "Years in safety, security and sustainability" },
  { value: "1,500+", label: "Management system implementations" },
  { value: "5,000+", label: "Personnel certifications" },
  { value: "100%", label: "Independent and impartial" },
] as const;

export const aboutStats = [
  { value: "20+", label: "Technical experts" },
  { value: "~30", label: "Years in safety, security and sustainability" },
  { value: "2+", label: "Locations across India" },
  { value: "~15+", label: "SQF employees" },
  { value: "100%", label: "Independent and impartial" },
] as const;

export const achievements = [
  { value: "1,500+", label: "Management system implementations" },
  { value: "100+", label: "Product certifications" },
  { value: "5,000+", label: "Personnel certifications" },
] as const;

export const steps = [
  {
    title: "See the gap",
    body: "Start from the standard, the site, and what a customer or assessor will actually look for.",
  },
  {
    title: "Build the system",
    body: "Put the management system into the way the organization already works, not into a file that sits on a shelf.",
  },
  {
    title: "Train the people",
    body: "Awareness, internal auditors, and the tools the team keeps using after the workshop.",
  },
  {
    title: "Stand ready",
    body: "Second-party audits and assessment preparation, so the findings are clear before a third party arrives.",
  },
] as const;

export const pillars = [
  {
    href: "/services",
    title: "Management systems",
    body: "Quality, safety, environment, information security, food safety and responsible business.",
  },
  {
    href: "/audits",
    title: "Audits & verification",
    body: "Agreed criteria, practical gap identification and a clear view of supply-chain performance.",
  },
  {
    href: "/training",
    title: "Training & development",
    body: "Management system awareness, internal auditing, social accountability and automotive quality tools.",
  },
  {
    href: "/services",
    hash: "products",
    title: "Product compliance",
    body: "Guidance on product requirements, certification readiness, testing and inspection needs.",
  },
] as const;

export const areas = [
  "Quality, automotive & specialist systems",
  "Environment, safety & sustainability",
  "Information security & business resilience",
  "Food safety & food-sector assurance",
  "Social accountability & responsible business",
  "Product compliance & approval readiness",
] as const;

export type Area = (typeof areas)[number];

export type Service = {
  code: string;
  title: string;
  summary: string;
  area: Area;
};

export const services: Service[] = [
  {
    code: "ISO 9001",
    title: "Quality management systems",
    summary:
      "Management system planning, process documentation, implementation and internal audit support.",
    area: areas[0],
  },
  {
    code: "IATF 16949",
    title: "Automotive quality management",
    summary:
      "Automotive system requirements and quality improvement, with guidance on the core quality tools.",
    area: areas[0],
  },
  {
    code: "ISO 13485",
    title: "Medical device quality management",
    summary: "Consultancy for quality management systems for medical devices.",
    area: areas[0],
  },
  {
    code: "ISO 15378",
    title: "Medicinal product packaging",
    summary:
      "Management system requirements for primary packaging materials for medicinal products.",
    area: areas[0],
  },
  {
    code: "ISO 21001",
    title: "Educational organizations",
    summary: "Management system consultancy for educational organizations.",
    area: areas[0],
  },
  {
    code: "GMP",
    title: "Good Manufacturing Practices",
    summary: "Readiness support for Good Manufacturing Practices in pharmaceutical industries.",
    area: areas[0],
  },
  {
    code: "ISO 14001",
    title: "Environmental management",
    summary:
      "Environmental aspects and impacts, compliance planning and management system implementation.",
    area: areas[1],
  },
  {
    code: "ISO 45001",
    title: "Occupational health & safety",
    summary:
      "Workplace hazard assessment, risk awareness and health and safety management systems.",
    area: areas[1],
  },
  {
    code: "ISO 50001",
    title: "Energy management",
    summary: "Consultancy on energy management system requirements and improvement frameworks.",
    area: areas[1],
  },
  {
    code: "CBAM",
    title: "Carbon Border Adjustment Mechanism",
    summary:
      "Guidance on understanding applicable CBAM requirements and readiness for your business.",
    area: areas[1],
  },
  {
    code: "ISO 27001",
    title: "Information security management",
    summary: "Consultancy on information security management system requirements.",
    area: areas[2],
  },
  {
    code: "TISAX",
    title: "Trusted Information Security Assessment Exchange",
    summary: "Readiness support for information security assessment requirements.",
    area: areas[2],
  },
  {
    code: "ISO 22301",
    title: "Business continuity management",
    summary: "Consultancy on business continuity management system requirements.",
    area: areas[2],
  },
  {
    code: "CTPAT",
    title: "Customs Trade Partnership Against Terrorism",
    summary: "Readiness consultancy for supply-chain security requirements under CTPAT.",
    area: areas[2],
  },
  {
    code: "ISO 22000",
    title: "Food safety management",
    summary: "Food safety management system requirements and implementation support.",
    area: areas[3],
  },
  {
    code: "FSSC 22000",
    title: "Food safety certification scheme",
    summary: "Consultancy and readiness support for FSSC 22000 requirements.",
    area: areas[3],
  },
  {
    code: "HACCP",
    title: "Hazard Analysis and Critical Control Points",
    summary:
      "Guidance on the Codex Alimentarius HACCP system, implementation and general principles of food hygiene.",
    area: areas[3],
  },
  {
    code: "BRCGS Food",
    title: "Global Standard for Food Safety",
    summary: "Consultancy and preparation for the BRCGS Global Standard for Food Safety.",
    area: areas[3],
  },
  {
    code: "ISO 26000",
    title: "Social responsibility guidance",
    summary:
      "Guidance on social responsibility. ISO 26000 is a guidance standard, rather than a certifiable management system.",
    area: areas[4],
  },
  {
    code: "SA8000",
    title: "Social accountability",
    summary: "Support in understanding and implementing social accountability requirements.",
    area: areas[4],
  },
  {
    code: "BSCI",
    title: "Business Social Compliance Initiative",
    summary: "Readiness support for business social compliance requirements.",
    area: areas[4],
  },
  {
    code: "WRAP",
    title: "Worldwide Responsible Accredited Production",
    summary: "Consultancy on responsible production requirements and assessment readiness.",
    area: areas[4],
  },
  {
    code: "SMETA",
    title: "Sedex Members Ethical Trade Audit",
    summary: "Preparation and readiness support for SMETA ethical trade audit requirements.",
    area: areas[4],
  },
  {
    code: "EcoVadis",
    title: "Sustainability assessment readiness",
    summary: "Support with readiness for sustainability assessment requirements.",
    area: areas[4],
  },
  {
    code: "CE Marking",
    title: "European product conformity",
    summary:
      "Consultancy on applicable CE marking requirements and preparation for the relevant conformity route.",
    area: areas[5],
  },
  {
    code: "UL Approval",
    title: "Product approval requirements",
    summary: "Guidance and preparation for applicable UL approval requirements.",
    area: areas[5],
  },
  {
    code: "BIS Approval",
    title: "Bureau of Indian Standards",
    summary: "Consultancy and readiness support for applicable BIS requirements.",
    area: areas[5],
  },
  {
    code: "ATEX",
    title: "Explosive atmospheres",
    summary:
      "Guidance on applicable ATEX requirements for products intended for explosive atmospheres.",
    area: areas[5],
  },
];

export const cycle = [
  {
    title: "Management systems & certification readiness",
    body: "System development, implementation support and preparation for external assessment.",
  },
  {
    title: "Testing & product certification support",
    body: "Help understanding product requirements and the relevant testing or certification route.",
  },
  {
    title: "Inspection support",
    body: "Discuss inspection needs within your product, process or supplier requirements.",
  },
  {
    title: "Advisory & training",
    body: "Practical guidance and professional development to build internal capability.",
  },
  {
    title: "Verification & validation",
    body: "Review the applicable requirements, scope and evidence needed for verification or validation.",
  },
] as const;

export const sectors = [
  "Chemical & Process",
  "Consumer Products & Retail",
  "Energy",
  "Healthcare & Medical Devices",
  "Infrastructure & Rail",
  "Manufacturing",
  "Mobility & Automotive",
  "Real Estate",
] as const;

export const trainingTracks = [
  {
    title: "Management systems",
    codes: "ISO 9001 · ISO 14001 · ISO 45001",
    service: "Training — Management systems",
    image: "/assets/images/learning-workshop.webp",
    alt: "Participants attending an SQF professional workshop",
    points: [
      "Internal auditor training on ISO 9001, ISO 14001 and ISO 45001",
      "Awareness of management systems and employee responsibilities",
      "Product life cycle awareness",
      "Environmental aspects and their impacts",
      "Hazard identification and risk assessment awareness (HIRAO)",
    ],
  },
  {
    title: "Social accountability",
    codes: "SA8000 · WRAP · BSCI · ISO 26000 · SMETA",
    service: "Training — Social accountability",
    image: "/assets/images/professional-training-group.webp",
    alt: "SQF professional training group in a conference room",
    points: [
      "Internal auditor training covering social accountability standards and frameworks",
      "Awareness of corporate social responsibility policies",
      "Understanding applicable social and ethical accountability requirements",
    ],
  },
  {
    title: "Automotive quality",
    codes: "IATF 16949 · Core tools · VDA",
    service: "Training — Automotive quality",
    image: "/assets/images/training-session.webp",
    alt: "Trainer presenting to participants at workshop tables",
    points: [
      "Internal auditor training on IATF 16949",
      "Awareness of the five core quality tools: APQP, PPAP, FMEA, MSA and SPC",
      "Awareness of VDA requirements",
    ],
  },
] as const;

export const clients = [
  { name: "FOX", file: "fox.png" },
  { name: "Godrej Agrovet", file: "godrej-agrovet.png" },
  { name: "Jindal Stainless", file: "jindal-stainless.png" },
  { name: "Caparo", file: "caparo.png" },
  { name: "Tata Projects", file: "tata-projects.png" },
  { name: "MSS Products", file: "mss-us.png" },
  { name: "Pik", file: "pik.png" },
  { name: "S D Fine-Chem", file: "sdfine.png" },
  { name: "Adam Fabriwerk", file: "adam-fabriwerk.png" },
  { name: "Tufropes", file: "tufropes.png" },
  { name: "Omea Solar", file: "omea.png" },
  { name: "Pelicans Group", file: "pelicans.png" },
  { name: "VFE", file: "vfe.png" },
  { name: "Polysil", file: "polysil.png" },
  { name: "Harish Textile Engineers", file: "harish-textile.png" },
] as const;

export const gallery = [
  {
    src: "/assets/images/training-participants.webp",
    alt: "Training participants and the trainer gathered for a group photograph",
    caption: "The people behind the progress",
  },
  {
    src: "/assets/images/recognition-ceremony.webp",
    alt: "Bouquet presentation during a professional recognition gathering",
    caption: "A moment of recognition",
  },
  {
    src: "/assets/images/professional-training-group.webp",
    alt: "A professional training group posing together in a conference room",
    caption: "Shared learning",
  },
  {
    src: "/assets/images/training-session.webp",
    alt: "Participants listening to a trainer during a classroom session",
    caption: "Knowledge into practice",
  },
  {
    src: "/assets/images/learning-workshop.webp",
    alt: "A workshop with participants seated at tables facing the presentation screen",
    caption: "Building capability",
  },
] as const;

export const why = [
  {
    title: "One-stop support",
    body: "Management system consultancy, product compliance readiness, testing and inspection support, and training.",
  },
  {
    title: "A wider network",
    body: "A business network that supports local operations and requirements wherever organizations operate.",
  },
  {
    title: "Added business value",
    body: "Vulnerabilities identified, with specific and clear recommendations for action.",
  },
  {
    title: "Quality experts",
    body: "Experienced professionals with qualifications and a hands-on understanding of implementation.",
  },
] as const;

export const auditCycle = [
  {
    title: "Agree the checklist",
    body: "Define the quality, safety and environmental criteria to be assessed.",
  },
  {
    title: "Assess the site",
    body: "Evaluate the site against the agreed scope and identify gaps.",
  },
  {
    title: "Review performance",
    body: "Use results to guide periodic assessments and annual site evaluation.",
  },
  {
    title: "Update and follow up",
    body: "Amend criteria when requirements change and track improvement needs.",
  },
] as const;

export const auditBenefits = [
  {
    title: "Understand gaps",
    body: "Assess site quality and environmental, occupational health and safety aspects against identified needs.",
  },
  {
    title: "External perspective",
    body: "Obtain an independent review against the criteria agreed for the audit engagement.",
  },
  {
    title: "Adapt to change",
    body: "Update the checklist when requirements, processes or expectations change.",
  },
  {
    title: "Consistent expectations",
    body: "Work towards agreed criteria across suppliers, manufacturers and warehouses.",
  },
] as const;

export const extraInterests = [
  "Free consultation",
  "Training / Internal Audits",
  "Training — Management systems",
  "Training — Social accountability",
  "Training — Automotive quality",
  "Second-party audits",
  "Verification / validation / inspection",
  "Other enquiry",
] as const;

export const interestOptions = [
  ...services.map((service) => service.code),
  ...extraInterests,
];

export const disclaimer =
  "Figures are as presented in the SQF company profile. Consultancy and training do not themselves confer certification or approval — that still depends on the scheme and the certification body.";

export function whatsappLink(text: string) {
  return `https://wa.me/${firm.whatsapp}?text=${encodeURIComponent(text)}`;
}
