import { createFileRoute } from "@tanstack/react-router";
import { Mail, MapPin, Phone } from "lucide-react";
import { firm, whatsappLink } from "@/data/site";
import { EnquiryForm } from "@/components/enquiry-form";
import { Kicker, Shell } from "@/components/shell";

type ContactSearch = { service?: string };

export const Route = createFileRoute("/contact")({
  validateSearch: (search: Record<string, unknown>): ContactSearch => {
    if (typeof search.service === "string" && search.service.trim()) {
      return { service: search.service.trim().slice(0, 120) };
    }
    return {};
  },
  head: () => ({
    meta: [
      { title: "Contact SQF — Consultancy, Training & Audit Enquiries | Shubhkiran Quality Forum" },
      {
        name: "description",
        content:
          "Talk to Shubhkiran Quality Forum in Nashik about consultancy, training, or audit readiness.",
      },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const { service = "" } = Route.useSearch();
  return (
    <Shell>
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-14 lg:grid-cols-2 lg:py-20">
        <div>
          <Kicker>Let’s move forward</Kicker>
          <h1 className="mt-3 font-display text-4xl font-semibold leading-tight sm:text-5xl">
            Your next step towards better.
          </h1>
          <p className="mt-4 text-lg text-muted">
            Tell us where you are and where you want to go. We’ll discuss the right consultancy,
            training, or audit-readiness support.
          </p>
          <ul className="mt-8 space-y-3">
            {firm.phones.map((phone) => (
              <li key={phone.tel}>
                <a
                  href={`tel:${phone.tel}`}
                  className="flex min-h-14 items-center gap-3 rounded-card bg-surface px-4 ring-1 ring-line"
                >
                  <Phone className="size-5 text-accent" aria-hidden />
                  <span>
                    <span className="block font-semibold">{phone.display}</span>
                    <span className="text-sm text-muted">{phone.label}</span>
                  </span>
                </a>
              </li>
            ))}
            <li>
              <a
                href={whatsappLink("Hello SQF, I would like to discuss consultancy or training.")}
                className="flex min-h-14 items-center gap-3 rounded-card bg-surface px-4 ring-1 ring-line"
              >
                <Phone className="size-5 text-accent" aria-hidden />
                <span>
                  <span className="block font-semibold">WhatsApp · {firm.whatsappDisplay}</span>
                  <span className="text-sm text-muted">Start a chat</span>
                </span>
              </a>
            </li>
            {firm.emails.map((email) => (
              <li key={email}>
                <a
                  href={`mailto:${email}`}
                  className="flex min-h-14 items-center gap-3 rounded-card bg-surface px-4 ring-1 ring-line"
                >
                  <Mail className="size-5 text-accent" aria-hidden />
                  <span className="font-semibold">{email}</span>
                </a>
              </li>
            ))}
            <li>
              <a
                href={firm.map}
                className="flex items-start gap-3 rounded-card bg-surface px-4 py-4 ring-1 ring-line"
              >
                <MapPin className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden />
                <span>
                  <span className="block font-semibold">Visit the office</span>
                  <span className="mt-1 block text-sm text-muted">{firm.address}</span>
                </span>
              </a>
            </li>
          </ul>
        </div>
        <EnquiryForm initialService={service} />
      </section>
    </Shell>
  );
}
