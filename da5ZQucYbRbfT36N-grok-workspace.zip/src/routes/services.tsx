import { createFileRoute } from "@tanstack/react-router";
import { cycle, sectors } from "@/data/site";
import { Catalogue } from "@/components/catalogue";
import { CloseBand, Kicker, PageIntro, Shell } from "@/components/shell";

type ServicesSearch = { q?: string; area?: string };

export const Route = createFileRoute("/services")({
  validateSearch: (search: Record<string, unknown>): ServicesSearch => {
    const next: ServicesSearch = {};
    if (typeof search.q === "string" && search.q.trim()) next.q = search.q.trim().slice(0, 80);
    if (typeof search.area === "string" && search.area && search.area !== "all") {
      next.area = search.area.slice(0, 80);
    }
    return next;
  },
  head: () => ({
    meta: [
      { title: "Services — ISO, Sustainability & Product Compliance | Shubhkiran Quality Forum" },
      {
        name: "description",
        content:
          "Explore SQF consultancy for management systems, sustainability, food safety, security, and product compliance readiness.",
      },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const { q = "", area = "all" } = Route.useSearch();
  return (
    <Shell>
      <PageIntro
        kicker="Services"
        title="The right expertise for your requirements."
        lede="Management system consultancy, sustainability and social accountability, food safety, security, and product compliance readiness."
      />
      <section className="mx-auto max-w-6xl px-5 pb-12">
        <Kicker>Across the business cycle</Kicker>
        <h2 className="mt-3 font-display text-3xl font-semibold">Connected support, from requirements to readiness.</h2>
        <ol className="mt-6 grid gap-3 md:grid-cols-5">
          {cycle.map((item, index) => (
            <li key={item.title} className="rounded-card bg-surface p-4 ring-1 ring-line">
              <p className="text-xs font-semibold text-accent">0{index + 1}</p>
              <h3 className="mt-2 font-semibold leading-snug">{item.title}</h3>
              <p className="mt-2 text-sm text-muted">{item.body}</p>
            </li>
          ))}
        </ol>
      </section>
      <section id="products" className="mx-auto max-w-6xl px-5 pb-12">
        <Kicker>Service catalogue</Kicker>
        <h2 className="mt-3 font-display text-3xl font-semibold">Find your standard. Plan your next step.</h2>
        <p className="mt-2 max-w-2xl text-muted">
          Search by a standard, scheme, industry or topic. Ask SQF to confirm the scope that applies to
          your organization.
        </p>
        <div className="mt-6">
          <Catalogue initialQuery={q} initialArea={area} />
        </div>
        <p className="mt-6 text-sm text-muted">
          SQF provides consultancy, training, and readiness support. Certification, product approvals,
          testing, inspection, verification, and validation vary by scheme. Consultancy does not itself
          confer certification or approval.
        </p>
      </section>
      <section id="sustainability" className="mx-auto max-w-6xl px-5 pb-4">
        <Kicker>Sectors we serve</Kicker>
        <h2 className="mt-3 font-display text-3xl font-semibold">Different industries. The same commitment to quality.</h2>
        <ul className="mt-6 flex flex-wrap gap-2">
          {sectors.map((sector) => (
            <li key={sector} className="rounded-full bg-surface px-4 py-2 text-sm font-semibold ring-1 ring-line">
              {sector}
            </li>
          ))}
        </ul>
        <p className="mt-4 text-sm text-muted">
          The practice also describes experience in electrical and electronics, pharmaceuticals, textiles,
          logistics, education, food, and other services.
        </p>
      </section>
      <CloseBand />
    </Shell>
  );
}
