import { createFileRoute } from "@tanstack/react-router";
import { aboutStats, achievements, firm, why } from "@/data/site";
import { CloseBand, ContactButton, GhostLink, Kicker, PageIntro, Shell } from "@/components/shell";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About SQF — Company Profile & Expertise | Shubhkiran Quality Forum" },
      {
        name: "description",
        content:
          "Shubhkiran Quality Forum is a Nashik consultancy and training practice of auditors and engineers, established in 1999.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <Shell>
      <PageIntro
        kicker="About us"
        title="Experience that turns requirements into progress."
        lede="We help organizations manage risk, strengthen management systems, and build the capability to keep improving."
        actions={
          <>
            <GhostLink href={firm.profile}>Download company profile</GhostLink>
            <ContactButton tone="ink">Talk to SQF</ContactButton>
          </>
        }
      />
      <section className="mx-auto grid max-w-6xl items-center gap-8 px-5 pb-16 lg:grid-cols-2">
        <img
          src="/assets/images/training-session.webp"
          alt="SQF workshop with a trainer and participants"
          className="aspect-[4/3] w-full rounded-card object-cover"
        />
        <div>
          <p className="text-sm font-semibold text-accent">Since {firm.established}</p>
          <h2 className="mt-2 font-display text-3xl font-semibold leading-tight">
            A practical partner for your organization.
          </h2>
          <p className="mt-4 text-muted">
            Shubhkiran Quality Forum is a consultancy and training organization of experienced auditors
            and engineers. The work spans management systems, audit readiness, professional development,
            and technical and sustainability requirements.
          </p>
          <p className="mt-3 text-muted">
            Led by <span className="font-semibold text-ink">{firm.leader}</span>, a {firm.leaderRole.toLowerCase()},
            SQF focuses on customized solutions, hands-on implementation, and knowledge transfer. An
            extensive network helps the practice assist organizations across India and support needs
            wherever they operate.
          </p>
          <blockquote className="mt-6 border-l-2 border-accent pl-4">
            <p className="font-display text-xl font-semibold leading-snug">
              “We believe in cultivating long-term relationships with our customers.”
            </p>
            <footer className="mt-2 text-sm text-muted">Shubhkiran Quality Forum</footer>
          </blockquote>
        </div>
      </section>

      <section className="bg-surface">
        <div className="mx-auto max-w-6xl px-5 py-16">
          <Kicker>At a glance</Kicker>
          <h2 className="mt-3 font-display text-4xl font-semibold">Expertise with a wider perspective.</h2>
          <dl className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {aboutStats.map((stat) => (
              <div key={stat.label} className="rounded-card bg-bg p-5 ring-1 ring-line">
                <dt className="font-display text-4xl font-semibold">{stat.value}</dt>
                <dd className="mt-2 text-sm text-muted">{stat.label}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-4 text-xs text-muted">
            Figures and the independence statement are as presented in the SQF company profile.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16">
        <Kicker>Achievements</Kicker>
        <h2 className="mt-3 font-display text-4xl font-semibold">A track record of supporting progress.</h2>
        <div className="mt-8 grid gap-3 md:grid-cols-3">
          {achievements.map((item) => (
            <article key={item.label} className="rounded-card bg-ink p-6 text-on-ink">
              <p className="font-display text-5xl font-semibold">{item.value}</p>
              <h3 className="mt-3 text-lg">{item.label}</h3>
            </article>
          ))}
        </div>
        <p className="mt-4 text-xs text-muted">
          Company-reported figures. Certification and approval arrangements depend on the applicable scheme.
        </p>
      </section>

      <section id="sustainability" className="mx-auto grid max-w-6xl gap-8 px-5 pb-8 lg:grid-cols-2">
        <div className="rounded-card bg-surface p-8 ring-1 ring-line">
          <Kicker>Sustainability</Kicker>
          <h2 className="mt-3 font-display text-3xl font-semibold leading-tight">
            Supporting the needs of tomorrow.
          </h2>
          <p className="mt-4 text-muted">
            SQF’s company profile sets out its alignment with the United Nations Sustainable Development
            Goals and support for the Paris Climate Agreement through consultancy and training in
            sustainable management systems.
          </p>
          <p className="mt-3 text-muted">
            The focus is on helping organizations understand risks and develop management systems that
            support safety, sustainability, and responsible business.
          </p>
          <div className="mt-6">
            <GhostLink href="/services">Explore sustainability services</GhostLink>
          </div>
        </div>
        <div>
          <Kicker>Why SQF</Kicker>
          <h2 className="mt-3 font-display text-3xl font-semibold">Clear advice. Practical value.</h2>
          <ul className="mt-6 space-y-4">
            {why.map((item) => (
              <li key={item.title} className="border-t border-line pt-4">
                <h3 className="font-semibold">{item.title}</h3>
                <p className="mt-1 text-sm text-muted">{item.body}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <CloseBand />
    </Shell>
  );
}
