import { createFileRoute } from "@tanstack/react-router";
import { clients } from "@/data/site";
import { PhotoGrid } from "@/components/gallery";
import { CloseBand, ContactButton, Kicker, PageIntro, Shell } from "@/components/shell";

export const Route = createFileRoute("/clients")({
  head: () => ({
    meta: [
      { title: "Clients & Training Gallery | Shubhkiran Quality Forum" },
      {
        name: "description",
        content:
          "Organizations featured in the SQF company profile, and photographs from the training community.",
      },
    ],
  }),
  component: ClientsPage,
});

function ClientsPage() {
  return (
    <Shell>
      <PageIntro
        kicker="Clients"
        title="Shared experience. Lasting relationships."
        lede="Client references from the SQF company profile, and moments from the training community."
        actions={<ContactButton>Work with SQF</ContactButton>}
      />
      <section className="mx-auto max-w-6xl px-5 pb-12">
        <Kicker>Client references</Kicker>
        <h2 className="mt-3 font-display text-3xl font-semibold">Organizations featured in the profile.</h2>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Named under “Key Client — Consulted Services”. The relationship is consultancy and training,
          not a claim that SQF certified these organizations.
        </p>
        <ul className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {clients.map((client) => (
            <li
              key={client.file}
              className="flex h-32 flex-col items-center justify-center gap-2 rounded-card bg-surface px-4 ring-1 ring-line"
            >
              <img
                src={`/assets/images/clients/${client.file}`}
                alt={`${client.name} logo`}
                className="max-h-12 w-full object-contain"
              />
              <span className="text-center text-xs font-semibold text-muted">{client.name}</span>
            </li>
          ))}
        </ul>
        <figure className="mt-8 overflow-hidden rounded-card bg-surface ring-1 ring-line">
          <img
            src="/assets/images/profile-client-panel.webp"
            alt="Complete client reference panel from the SQF company profile, including all logos as supplied"
            className="w-full object-contain"
          />
          <figcaption className="px-5 py-4 text-sm text-muted">
            The complete panel from the company profile, including additional logo-only entries.
          </figcaption>
        </figure>
      </section>
      <section id="training-gallery" className="mx-auto max-w-6xl px-5 pb-4">
        <Kicker>Training community</Kicker>
        <h2 className="mt-3 font-display text-3xl font-semibold">Learning together. Growing stronger.</h2>
        <p className="mt-2 mb-6 text-muted">Select a photograph to view it larger.</p>
        <PhotoGrid />
      </section>
      <CloseBand />
    </Shell>
  );
}
