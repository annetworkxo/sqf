import { createFileRoute } from "@tanstack/react-router";
import { auditBenefits, auditCycle } from "@/data/site";
import { CloseBand, ContactButton, Kicker, PageIntro, Shell } from "@/components/shell";

export const Route = createFileRoute("/audits")({
  head: () => ({
    meta: [
      { title: "Second-Party Audits, Verification & Inspection Support | Shubhkiran Quality Forum" },
      {
        name: "description",
        content:
          "Second-party audit support against agreed quality, safety and environmental criteria, plus verification and inspection readiness.",
      },
    ],
  }),
  component: AuditsPage,
});

const frequencies = ["Quarterly", "Half-yearly", "Yearly"];

function AuditsPage() {
  return (
    <Shell>
      <PageIntro
        kicker="Audits & verification"
        title="A clear view. A stronger supply chain."
        lede="Second-party audit support built around mutually agreed quality, safety, and environmental criteria."
        actions={<ContactButton service="Second-party audits">Discuss an audit</ContactButton>}
      />
      <section className="mx-auto grid max-w-6xl gap-8 px-5 pb-12 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <Kicker>Second-party audits</Kicker>
          <h2 className="mt-3 font-display text-3xl font-semibold">Agreed criteria. Actionable findings.</h2>
          <p className="mt-3 text-muted">
            Assess sites against a checklist that reflects your requirements. Use the findings to identify
            gaps, review performance, and plan follow-up.
          </p>
          <ul className="mt-5 space-y-2 text-sm">
            {[
              "Quality, safety and environmental aspects",
              "Suppliers, manufacturers and warehouses",
              "Checklists updated when requirements change",
              "Annual evaluation of each site’s performance",
            ].map((item) => (
              <li key={item} className="rounded-2xl bg-surface px-4 py-3 ring-1 ring-line">
                {item}
              </li>
            ))}
          </ul>
        </div>
        <aside className="rounded-card bg-ink p-6 text-on-ink lg:col-span-2">
          <Kicker onDark>Assessment frequency</Kicker>
          <h3 className="mt-3 font-display text-2xl font-semibold">A schedule shaped by audit results.</h3>
          <p className="mt-3 text-sm text-on-ink/80">
            Frequency and scope are agreed for the engagement, based on site requirements and outcomes.
          </p>
          <ul className="mt-5 flex flex-wrap gap-2">
            {frequencies.map((item) => (
              <li key={item} className="rounded-full bg-on-ink px-3 py-2 text-sm font-semibold text-ink">
                {item}
              </li>
            ))}
          </ul>
        </aside>
      </section>
      <section className="mx-auto max-w-6xl px-5 pb-12">
        <Kicker>How it works</Kicker>
        <h2 className="mt-3 font-display text-3xl font-semibold">A practical audit cycle.</h2>
        <ol className="mt-6 grid gap-3 md:grid-cols-4">
          {auditCycle.map((step, index) => (
            <li key={step.title} className="rounded-card bg-surface p-5 ring-1 ring-line">
              <p className="text-xs font-semibold text-accent">0{index + 1}</p>
              <h3 className="mt-2 font-display text-xl font-semibold">{step.title}</h3>
              <p className="mt-2 text-sm text-muted">{step.body}</p>
            </li>
          ))}
        </ol>
      </section>
      <section className="mx-auto max-w-6xl px-5 pb-4">
        <Kicker>What you get</Kicker>
        <h2 className="mt-3 font-display text-3xl font-semibold">Confidence across the supply chain.</h2>
        <div className="mt-6 grid gap-3 md:grid-cols-2">
          {auditBenefits.map((item) => (
            <article key={item.title} className="rounded-card bg-surface p-5 ring-1 ring-line">
              <h3 className="font-display text-xl font-semibold">{item.title}</h3>
              <p className="mt-2 text-sm text-muted">{item.body}</p>
            </article>
          ))}
        </div>
        <div className="mt-6 rounded-card border border-dashed border-line p-6">
          <h3 className="font-display text-2xl font-semibold">Verification, validation and inspection.</h3>
          <p className="mt-2 max-w-3xl text-muted">
            The profile also includes verification, validation, inspection, testing, and
            certification-related support across the business cycle. Contact SQF to discuss the relevant
            scope, methods, and delivery arrangements.
          </p>
          <div className="mt-4">
            <ContactButton service="Verification / validation / inspection" tone="ink">
              Discuss your scope
            </ContactButton>
          </div>
        </div>
      </section>
      <CloseBand />
    </Shell>
  );
}
