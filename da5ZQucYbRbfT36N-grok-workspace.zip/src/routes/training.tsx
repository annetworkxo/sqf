import { createFileRoute, Link } from "@tanstack/react-router";
import { trainingTracks } from "@/data/site";
import { CloseBand, ContactButton, Kicker, PageIntro, Shell } from "@/components/shell";

export const Route = createFileRoute("/training")({
  head: () => ({
    meta: [
      { title: "Training & Personnel Development — ISO, Social & Automotive | Shubhkiran Quality Forum" },
      {
        name: "description",
        content:
          "SQF training in management systems, social accountability and automotive quality tools, including internal auditor programmes.",
      },
    ],
  }),
  component: TrainingPage,
});

function TrainingPage() {
  return (
    <Shell>
      <PageIntro
        kicker="Training"
        title="Knowledge that works. People who improve."
        lede="Build awareness, develop internal auditors, and strengthen practical quality skills with SQF’s professional training programmes."
        actions={<ContactButton service="Training / Internal Audits">Discuss a programme</ContactButton>}
      />
      <section className="mx-auto max-w-6xl px-5 pb-8">
        <Kicker>Programmes</Kicker>
        <h2 className="mt-3 font-display text-3xl font-semibold">Choose a learning path.</h2>
        <p className="mt-2 max-w-2xl text-muted">
          Share your team’s needs and SQF will discuss the topics and programme scope. Dates, delivery,
          duration and fees are confirmed with the team.
        </p>
        <div className="mt-8 grid gap-4">
          {trainingTracks.map((track) => (
            <article
              key={track.title}
              className="grid overflow-hidden rounded-card bg-surface ring-1 ring-line lg:grid-cols-2"
            >
              <img src={track.image} alt={track.alt} className="h-full min-h-64 w-full object-cover" />
              <div className="p-6 sm:p-8">
                <p className="text-xs font-semibold tracking-wide text-accent">{track.codes}</p>
                <h3 className="mt-2 font-display text-3xl font-semibold">{track.title}</h3>
                <ul className="mt-4 space-y-2 text-sm text-muted">
                  {track.points.map((point) => (
                    <li key={point} className="border-t border-line pt-2">
                      {point}
                    </li>
                  ))}
                </ul>
                <Link
                  to="/contact"
                  search={{ service: track.service }}
                  className="mt-5 inline-flex min-h-11 items-center font-semibold"
                >
                  Enquire about this track
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-5 py-8">
        <div className="rounded-card bg-ink p-8 text-on-ink md:p-10">
          <Kicker onDark>Personnel certification</Kicker>
          <h2 className="mt-3 font-display text-3xl font-semibold">Build capability. Understand the pathway.</h2>
          <p className="mt-3 max-w-2xl text-on-ink/80">
            Training and personnel certification are part of the SQF portfolio. Discuss the programme,
            assessment, eligibility and certificate arrangements before booking.
          </p>
          <Link to="/clients" hash="training-gallery" className="mt-5 inline-flex min-h-11 items-center font-semibold">
            See the training community
          </Link>
        </div>
      </section>
      <CloseBand />
    </Shell>
  );
}
