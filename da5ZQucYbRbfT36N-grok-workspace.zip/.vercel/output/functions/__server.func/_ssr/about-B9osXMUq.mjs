import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as why, a as PageIntro, c as achievements, i as Kicker, m as firm, n as ContactButton, o as Shell, r as GhostLink, s as aboutStats, t as CloseBand } from "./shell-Bfw5R1rV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-B9osXMUq.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			kicker: "About us",
			title: "Experience that turns requirements into progress.",
			lede: "We help organizations manage risk, strengthen management systems, and build the capability to keep improving.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostLink, {
				href: firm.profile,
				children: "Download company profile"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactButton, {
				tone: "ink",
				children: "Talk to SQF"
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl items-center gap-8 px-5 pb-16 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/assets/images/training-session.webp",
				alt: "SQF workshop with a trainer and participants",
				className: "aspect-[4/3] w-full rounded-card object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-semibold text-accent",
					children: ["Since ", firm.established]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-3xl font-semibold leading-tight",
					children: "A practical partner for your organization."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted",
					children: "Shubhkiran Quality Forum is a consultancy and training organization of experienced auditors and engineers. The work spans management systems, audit readiness, professional development, and technical and sustainability requirements."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-muted",
					children: [
						"Led by ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-ink",
							children: firm.leader
						}),
						", a ",
						firm.leaderRole.toLowerCase(),
						", SQF focuses on customized solutions, hands-on implementation, and knowledge transfer. An extensive network helps the practice assist organizations across India and support needs wherever they operate."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
					className: "mt-6 border-l-2 border-accent pl-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl font-semibold leading-snug",
						children: "“We believe in cultivating long-term relationships with our customers.”"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
						className: "mt-2 text-sm text-muted",
						children: "Shubhkiran Quality Forum"
					})]
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "At a glance" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl font-semibold",
						children: "Expertise with a wider perspective."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-5",
						children: aboutStats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-card bg-bg p-5 ring-1 ring-line",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-display text-4xl font-semibold",
								children: stat.value
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-2 text-sm text-muted",
								children: stat.label
							})]
						}, stat.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs text-muted",
						children: "Figures and the independence statement are as presented in the SQF company profile."
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Achievements" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl font-semibold",
					children: "A track record of supporting progress."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-3 md:grid-cols-3",
					children: achievements.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card bg-ink p-6 text-on-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-5xl font-semibold",
							children: item.value
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 text-lg",
							children: item.label
						})]
					}, item.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted",
					children: "Company-reported figures. Certification and approval arrangements depend on the applicable scheme."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "sustainability",
			className: "mx-auto grid max-w-6xl gap-8 px-5 pb-8 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-card bg-surface p-8 ring-1 ring-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Sustainability" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-3xl font-semibold leading-tight",
						children: "Supporting the needs of tomorrow."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-muted",
						children: "SQF’s company profile sets out its alignment with the United Nations Sustainable Development Goals and support for the Paris Climate Agreement through consultancy and training in sustainable management systems."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted",
						children: "The focus is on helping organizations understand risks and develop management systems that support safety, sustainability, and responsible business."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostLink, {
							href: "/services",
							children: "Explore sustainability services"
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Why SQF" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold",
					children: "Clear advice. Practical value."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 space-y-4",
					children: why.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-line pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: item.body
						})]
					}, item.title))
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseBand, {})
	] });
}
//#endregion
export { AboutPage as component };
