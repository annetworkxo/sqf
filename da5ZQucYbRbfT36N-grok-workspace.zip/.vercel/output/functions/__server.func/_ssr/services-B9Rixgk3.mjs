import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Search, u as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { a as PageIntro, b as sectors, i as Kicker, l as areas, o as Shell, p as cycle, t as CloseBand, x as services } from "./shell-Bfw5R1rV.mjs";
import { n as Route$1 } from "./router-DMcMyqK2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-B9Rixgk3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Catalogue({ initialQuery = "", initialArea = "all" }) {
	const [query, setQuery] = (0, import_react.useState)(initialQuery);
	const [area, setArea] = (0, import_react.useState)(areas.includes(initialArea) ? initialArea : "all");
	const results = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return services.filter((service) => {
			if (area !== "all" && service.area !== area) return false;
			if (!q) return true;
			return `${service.code} ${service.title} ${service.summary} ${service.area}`.toLowerCase().includes(q);
		});
	}, [query, area]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-card bg-surface p-4 ring-1 ring-line sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "block text-sm font-semibold",
					htmlFor: "catalogue-search",
					children: "Search the catalogue"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center gap-2 rounded-full border border-line bg-bg px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						className: "size-4 text-muted",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "catalogue-search",
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "ISO 9001, IATF, food safety, BIS…",
						className: "h-12 w-full bg-transparent text-base outline-none placeholder:text-muted"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-2 overflow-x-auto pb-1",
					role: "tablist",
					"aria-label": "Service area",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: area === "all",
						onClick: () => setArea("all"),
						children: "All"
					}), areas.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: area === item,
						onClick: () => setArea(item),
						children: item
					}, item))]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-5 text-sm text-muted",
			children: [
				results.length,
				" ",
				results.length === 1 ? "service" : "services"
			]
		}),
		results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 rounded-card border border-dashed border-line bg-surface p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-semibold",
					children: "Nothing matches that yet."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Try another term, or ask SQF to confirm the scope for your organization."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/contact",
					search: { service: query.slice(0, 120) || "Other enquiry" },
					className: "mt-4 inline-flex min-h-11 items-center gap-2 font-semibold text-accent",
					children: ["Ask about this requirement", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
						className: "size-4",
						"aria-hidden": true
					})]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-3 sm:grid-cols-2",
			children: results.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-card bg-surface p-5 ring-1 ring-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-wide text-accent",
						children: service.area
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-2 font-display text-2xl font-semibold",
						children: service.code
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-medium",
						children: service.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: service.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/contact",
						search: { service: service.code },
						className: "mt-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold",
						children: ["Enquire", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
							className: "size-4",
							"aria-hidden": true
						})]
					})
				]
			}, service.code))
		})
	] });
}
function Chip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		role: "tab",
		"aria-selected": active,
		onClick,
		className: `shrink-0 rounded-full px-3 py-2 text-sm font-semibold ${active ? "bg-ink text-on-ink" : "bg-bg text-muted"}`,
		children
	});
}
function ServicesPage() {
	const { q = "", area = "all" } = Route$1.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			kicker: "Services",
			title: "The right expertise for your requirements.",
			lede: "Management system consultancy, sustainability and social accountability, food safety, security, and product compliance readiness."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 pb-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Across the business cycle" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold",
					children: "Connected support, from requirements to readiness."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 grid gap-3 md:grid-cols-5",
					children: cycle.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-card bg-surface p-4 ring-1 ring-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs font-semibold text-accent",
								children: ["0", index + 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-semibold leading-snug",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: item.body
							})
						]
					}, item.title))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "products",
			className: "mx-auto max-w-6xl px-5 pb-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Service catalogue" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold",
					children: "Find your standard. Plan your next step."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-muted",
					children: "Search by a standard, scheme, industry or topic. Ask SQF to confirm the scope that applies to your organization."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Catalogue, {
						initialQuery: q,
						initialArea: area
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-muted",
					children: "SQF provides consultancy, training, and readiness support. Certification, product approvals, testing, inspection, verification, and validation vary by scheme. Consultancy does not itself confer certification or approval."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "sustainability",
			className: "mx-auto max-w-6xl px-5 pb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Sectors we serve" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold",
					children: "Different industries. The same commitment to quality."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 flex flex-wrap gap-2",
					children: sectors.map((sector) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-full bg-surface px-4 py-2 text-sm font-semibold ring-1 ring-line",
						children: sector
					}, sector))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: "The practice also describes experience in electrical and electronics, pharmaceuticals, textiles, logistics, education, food, and other services."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseBand, {})
	] });
}
//#endregion
export { ServicesPage as component };
