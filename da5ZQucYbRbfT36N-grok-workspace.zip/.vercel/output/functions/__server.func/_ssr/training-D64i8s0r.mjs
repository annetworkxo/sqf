import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PageIntro, i as Kicker, n as ContactButton, o as Shell, t as CloseBand, w as trainingTracks } from "./shell-Bfw5R1rV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/training-D64i8s0r.js
var import_jsx_runtime = require_jsx_runtime();
function TrainingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			kicker: "Training",
			title: "Knowledge that works. People who improve.",
			lede: "Build awareness, develop internal auditors, and strengthen practical quality skills with SQF’s professional training programmes.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactButton, {
				service: "Training / Internal Audits",
				children: "Discuss a programme"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Programmes" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold",
					children: "Choose a learning path."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-muted",
					children: "Share your team’s needs and SQF will discuss the topics and programme scope. Dates, delivery, duration and fees are confirmed with the team."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4",
					children: trainingTracks.map((track) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "grid overflow-hidden rounded-card bg-surface ring-1 ring-line lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: track.image,
							alt: track.alt,
							className: "h-full min-h-64 w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-6 sm:p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-wide text-accent",
									children: track.codes
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 font-display text-3xl font-semibold",
									children: track.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-4 space-y-2 text-sm text-muted",
									children: track.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "border-t border-line pt-2",
										children: point
									}, point))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/contact",
									search: { service: track.service },
									className: "mt-5 inline-flex min-h-11 items-center font-semibold",
									children: "Enquire about this track"
								})
							]
						})]
					}, track.title))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-6xl px-5 py-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-card bg-ink p-8 text-on-ink md:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, {
						onDark: true,
						children: "Personnel certification"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-3xl font-semibold",
						children: "Build capability. Understand the pathway."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-on-ink/80",
						children: "Training and personnel certification are part of the SQF portfolio. Discuss the programme, assessment, eligibility and certificate arrangements before booking."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/clients",
						hash: "training-gallery",
						className: "mt-5 inline-flex min-h-11 items-center font-semibold",
						children: "See the training community"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseBand, {})
	] });
}
//#endregion
export { TrainingPage as component };
