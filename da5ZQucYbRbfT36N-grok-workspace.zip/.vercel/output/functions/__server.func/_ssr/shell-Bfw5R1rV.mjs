import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Menu, t as X, u as ArrowUpRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-Bfw5R1rV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var firm = {
	name: "Shubhkiran Quality Forum",
	short: "SQF",
	city: "Nashik, Maharashtra",
	established: 1999,
	tagline: "Better systems. Stronger teams. Lasting quality.",
	lede: "Quality goes beyond a certificate. We help you build practical management systems, prepare for audits, and give your people the skills to keep improving.",
	leader: "Mr. Vilas Shinde",
	leaderRole: "Mechanical engineer and lead auditor",
	address: "Flat No. 1105, Wing B, Harivishwa Apartment, Khanderao Nagar, Behind Express In Hotel, Pathardi Phata, Nashik – 422010, Maharashtra",
	map: "https://www.google.com/maps/search/?api=1&query=Harivishwa+Apartment+Pathardi+Phata+Nashik+422010",
	emails: ["shubhkiranquality@gmail.com", "vishwaqc@gmail.com"],
	whatsapp: "917875556748",
	whatsappDisplay: "+91 78755 56748",
	phones: [
		{
			label: "Vilas Shinde",
			display: "+91 93703 17764",
			tel: "+919370317764"
		},
		{
			label: "Mobile",
			display: "+91 78755 56741",
			tel: "+917875556741"
		},
		{
			label: "Office",
			display: "0253 2380070",
			tel: "+912532380070"
		}
	],
	profile: "/assets/documents/sqf-company-profile.pdf",
	offer: "Free consultation",
	offerWindow: "10 November – 10 December 2026"
};
var logo = "/assets/images/sqf-logo-mark.png";
var standards = [
	{
		code: "ISO 9001",
		label: "Quality"
	},
	{
		code: "IATF 16949",
		label: "Automotive"
	},
	{
		code: "ISO 14001",
		label: "Environment"
	},
	{
		code: "ISO 45001",
		label: "Health & safety"
	},
	{
		code: "ISO 22000",
		label: "Food safety"
	}
];
var homeStats = [
	{
		value: "20+",
		label: "Technical experts"
	},
	{
		value: "~30",
		label: "Years in safety, security and sustainability"
	},
	{
		value: "1,500+",
		label: "Management system implementations"
	},
	{
		value: "5,000+",
		label: "Personnel certifications"
	},
	{
		value: "100%",
		label: "Independent and impartial"
	}
];
var aboutStats = [
	{
		value: "20+",
		label: "Technical experts"
	},
	{
		value: "~30",
		label: "Years in safety, security and sustainability"
	},
	{
		value: "2+",
		label: "Locations across India"
	},
	{
		value: "~15+",
		label: "SQF employees"
	},
	{
		value: "100%",
		label: "Independent and impartial"
	}
];
var achievements = [
	{
		value: "1,500+",
		label: "Management system implementations"
	},
	{
		value: "100+",
		label: "Product certifications"
	},
	{
		value: "5,000+",
		label: "Personnel certifications"
	}
];
var steps = [
	{
		title: "See the gap",
		body: "Start from the standard, the site, and what a customer or assessor will actually look for."
	},
	{
		title: "Build the system",
		body: "Put the management system into the way the organization already works, not into a file that sits on a shelf."
	},
	{
		title: "Train the people",
		body: "Awareness, internal auditors, and the tools the team keeps using after the workshop."
	},
	{
		title: "Stand ready",
		body: "Second-party audits and assessment preparation, so the findings are clear before a third party arrives."
	}
];
var pillars = [
	{
		href: "/services",
		title: "Management systems",
		body: "Quality, safety, environment, information security, food safety and responsible business."
	},
	{
		href: "/audits",
		title: "Audits & verification",
		body: "Agreed criteria, practical gap identification and a clear view of supply-chain performance."
	},
	{
		href: "/training",
		title: "Training & development",
		body: "Management system awareness, internal auditing, social accountability and automotive quality tools."
	},
	{
		href: "/services",
		hash: "products",
		title: "Product compliance",
		body: "Guidance on product requirements, certification readiness, testing and inspection needs."
	}
];
var areas = [
	"Quality, automotive & specialist systems",
	"Environment, safety & sustainability",
	"Information security & business resilience",
	"Food safety & food-sector assurance",
	"Social accountability & responsible business",
	"Product compliance & approval readiness"
];
var services = [
	{
		code: "ISO 9001",
		title: "Quality management systems",
		summary: "Management system planning, process documentation, implementation and internal audit support.",
		area: areas[0]
	},
	{
		code: "IATF 16949",
		title: "Automotive quality management",
		summary: "Automotive system requirements and quality improvement, with guidance on the core quality tools.",
		area: areas[0]
	},
	{
		code: "ISO 13485",
		title: "Medical device quality management",
		summary: "Consultancy for quality management systems for medical devices.",
		area: areas[0]
	},
	{
		code: "ISO 15378",
		title: "Medicinal product packaging",
		summary: "Management system requirements for primary packaging materials for medicinal products.",
		area: areas[0]
	},
	{
		code: "ISO 21001",
		title: "Educational organizations",
		summary: "Management system consultancy for educational organizations.",
		area: areas[0]
	},
	{
		code: "GMP",
		title: "Good Manufacturing Practices",
		summary: "Readiness support for Good Manufacturing Practices in pharmaceutical industries.",
		area: areas[0]
	},
	{
		code: "ISO 14001",
		title: "Environmental management",
		summary: "Environmental aspects and impacts, compliance planning and management system implementation.",
		area: areas[1]
	},
	{
		code: "ISO 45001",
		title: "Occupational health & safety",
		summary: "Workplace hazard assessment, risk awareness and health and safety management systems.",
		area: areas[1]
	},
	{
		code: "ISO 50001",
		title: "Energy management",
		summary: "Consultancy on energy management system requirements and improvement frameworks.",
		area: areas[1]
	},
	{
		code: "CBAM",
		title: "Carbon Border Adjustment Mechanism",
		summary: "Guidance on understanding applicable CBAM requirements and readiness for your business.",
		area: areas[1]
	},
	{
		code: "ISO 27001",
		title: "Information security management",
		summary: "Consultancy on information security management system requirements.",
		area: areas[2]
	},
	{
		code: "TISAX",
		title: "Trusted Information Security Assessment Exchange",
		summary: "Readiness support for information security assessment requirements.",
		area: areas[2]
	},
	{
		code: "ISO 22301",
		title: "Business continuity management",
		summary: "Consultancy on business continuity management system requirements.",
		area: areas[2]
	},
	{
		code: "CTPAT",
		title: "Customs Trade Partnership Against Terrorism",
		summary: "Readiness consultancy for supply-chain security requirements under CTPAT.",
		area: areas[2]
	},
	{
		code: "ISO 22000",
		title: "Food safety management",
		summary: "Food safety management system requirements and implementation support.",
		area: areas[3]
	},
	{
		code: "FSSC 22000",
		title: "Food safety certification scheme",
		summary: "Consultancy and readiness support for FSSC 22000 requirements.",
		area: areas[3]
	},
	{
		code: "HACCP",
		title: "Hazard Analysis and Critical Control Points",
		summary: "Guidance on the Codex Alimentarius HACCP system, implementation and general principles of food hygiene.",
		area: areas[3]
	},
	{
		code: "BRCGS Food",
		title: "Global Standard for Food Safety",
		summary: "Consultancy and preparation for the BRCGS Global Standard for Food Safety.",
		area: areas[3]
	},
	{
		code: "ISO 26000",
		title: "Social responsibility guidance",
		summary: "Guidance on social responsibility. ISO 26000 is a guidance standard, rather than a certifiable management system.",
		area: areas[4]
	},
	{
		code: "SA8000",
		title: "Social accountability",
		summary: "Support in understanding and implementing social accountability requirements.",
		area: areas[4]
	},
	{
		code: "BSCI",
		title: "Business Social Compliance Initiative",
		summary: "Readiness support for business social compliance requirements.",
		area: areas[4]
	},
	{
		code: "WRAP",
		title: "Worldwide Responsible Accredited Production",
		summary: "Consultancy on responsible production requirements and assessment readiness.",
		area: areas[4]
	},
	{
		code: "SMETA",
		title: "Sedex Members Ethical Trade Audit",
		summary: "Preparation and readiness support for SMETA ethical trade audit requirements.",
		area: areas[4]
	},
	{
		code: "EcoVadis",
		title: "Sustainability assessment readiness",
		summary: "Support with readiness for sustainability assessment requirements.",
		area: areas[4]
	},
	{
		code: "CE Marking",
		title: "European product conformity",
		summary: "Consultancy on applicable CE marking requirements and preparation for the relevant conformity route.",
		area: areas[5]
	},
	{
		code: "UL Approval",
		title: "Product approval requirements",
		summary: "Guidance and preparation for applicable UL approval requirements.",
		area: areas[5]
	},
	{
		code: "BIS Approval",
		title: "Bureau of Indian Standards",
		summary: "Consultancy and readiness support for applicable BIS requirements.",
		area: areas[5]
	},
	{
		code: "ATEX",
		title: "Explosive atmospheres",
		summary: "Guidance on applicable ATEX requirements for products intended for explosive atmospheres.",
		area: areas[5]
	}
];
var cycle = [
	{
		title: "Management systems & certification readiness",
		body: "System development, implementation support and preparation for external assessment."
	},
	{
		title: "Testing & product certification support",
		body: "Help understanding product requirements and the relevant testing or certification route."
	},
	{
		title: "Inspection support",
		body: "Discuss inspection needs within your product, process or supplier requirements."
	},
	{
		title: "Advisory & training",
		body: "Practical guidance and professional development to build internal capability."
	},
	{
		title: "Verification & validation",
		body: "Review the applicable requirements, scope and evidence needed for verification or validation."
	}
];
var sectors = [
	"Chemical & Process",
	"Consumer Products & Retail",
	"Energy",
	"Healthcare & Medical Devices",
	"Infrastructure & Rail",
	"Manufacturing",
	"Mobility & Automotive",
	"Real Estate"
];
var trainingTracks = [
	{
		title: "Management systems",
		codes: "ISO 9001 · ISO 14001 · ISO 45001",
		service: "Training — Management systems",
		image: "/assets/images/learning-workshop.webp",
		alt: "Participants attending an SQF professional workshop",
		points: [
			"Internal auditor training on ISO 9001, ISO 14001 and ISO 45001",
			"Awareness of management systems and employee responsibilities",
			"Product life cycle awareness",
			"Environmental aspects and their impacts",
			"Hazard identification and risk assessment awareness (HIRAO)"
		]
	},
	{
		title: "Social accountability",
		codes: "SA8000 · WRAP · BSCI · ISO 26000 · SMETA",
		service: "Training — Social accountability",
		image: "/assets/images/professional-training-group.webp",
		alt: "SQF professional training group in a conference room",
		points: [
			"Internal auditor training covering social accountability standards and frameworks",
			"Awareness of corporate social responsibility policies",
			"Understanding applicable social and ethical accountability requirements"
		]
	},
	{
		title: "Automotive quality",
		codes: "IATF 16949 · Core tools · VDA",
		service: "Training — Automotive quality",
		image: "/assets/images/training-session.webp",
		alt: "Trainer presenting to participants at workshop tables",
		points: [
			"Internal auditor training on IATF 16949",
			"Awareness of the five core quality tools: APQP, PPAP, FMEA, MSA and SPC",
			"Awareness of VDA requirements"
		]
	}
];
var clients = [
	{
		name: "FOX",
		file: "fox.png"
	},
	{
		name: "Godrej Agrovet",
		file: "godrej-agrovet.png"
	},
	{
		name: "Jindal Stainless",
		file: "jindal-stainless.png"
	},
	{
		name: "Caparo",
		file: "caparo.png"
	},
	{
		name: "Tata Projects",
		file: "tata-projects.png"
	},
	{
		name: "MSS Products",
		file: "mss-us.png"
	},
	{
		name: "Pik",
		file: "pik.png"
	},
	{
		name: "S D Fine-Chem",
		file: "sdfine.png"
	},
	{
		name: "Adam Fabriwerk",
		file: "adam-fabriwerk.png"
	},
	{
		name: "Tufropes",
		file: "tufropes.png"
	},
	{
		name: "Omea Solar",
		file: "omea.png"
	},
	{
		name: "Pelicans Group",
		file: "pelicans.png"
	},
	{
		name: "VFE",
		file: "vfe.png"
	},
	{
		name: "Polysil",
		file: "polysil.png"
	},
	{
		name: "Harish Textile Engineers",
		file: "harish-textile.png"
	}
];
var gallery = [
	{
		src: "/assets/images/training-participants.webp",
		alt: "Training participants and the trainer gathered for a group photograph",
		caption: "The people behind the progress"
	},
	{
		src: "/assets/images/recognition-ceremony.webp",
		alt: "Bouquet presentation during a professional recognition gathering",
		caption: "A moment of recognition"
	},
	{
		src: "/assets/images/professional-training-group.webp",
		alt: "A professional training group posing together in a conference room",
		caption: "Shared learning"
	},
	{
		src: "/assets/images/training-session.webp",
		alt: "Participants listening to a trainer during a classroom session",
		caption: "Knowledge into practice"
	},
	{
		src: "/assets/images/learning-workshop.webp",
		alt: "A workshop with participants seated at tables facing the presentation screen",
		caption: "Building capability"
	}
];
var why = [
	{
		title: "One-stop support",
		body: "Management system consultancy, product compliance readiness, testing and inspection support, and training."
	},
	{
		title: "A wider network",
		body: "A business network that supports local operations and requirements wherever organizations operate."
	},
	{
		title: "Added business value",
		body: "Vulnerabilities identified, with specific and clear recommendations for action."
	},
	{
		title: "Quality experts",
		body: "Experienced professionals with qualifications and a hands-on understanding of implementation."
	}
];
var auditCycle = [
	{
		title: "Agree the checklist",
		body: "Define the quality, safety and environmental criteria to be assessed."
	},
	{
		title: "Assess the site",
		body: "Evaluate the site against the agreed scope and identify gaps."
	},
	{
		title: "Review performance",
		body: "Use results to guide periodic assessments and annual site evaluation."
	},
	{
		title: "Update and follow up",
		body: "Amend criteria when requirements change and track improvement needs."
	}
];
var auditBenefits = [
	{
		title: "Understand gaps",
		body: "Assess site quality and environmental, occupational health and safety aspects against identified needs."
	},
	{
		title: "External perspective",
		body: "Obtain an independent review against the criteria agreed for the audit engagement."
	},
	{
		title: "Adapt to change",
		body: "Update the checklist when requirements, processes or expectations change."
	},
	{
		title: "Consistent expectations",
		body: "Work towards agreed criteria across suppliers, manufacturers and warehouses."
	}
];
var extraInterests = [
	"Free consultation",
	"Training / Internal Audits",
	"Training — Management systems",
	"Training — Social accountability",
	"Training — Automotive quality",
	"Second-party audits",
	"Verification / validation / inspection",
	"Other enquiry"
];
var interestOptions = [...services.map((service) => service.code), ...extraInterests];
var disclaimer = "Figures are as presented in the SQF company profile. Consultancy and training do not themselves confer certification or approval — that still depends on the scheme and the certification body.";
function whatsappLink(text) {
	return `https://wa.me/${firm.whatsapp}?text=${encodeURIComponent(text)}`;
}
var nav = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/about",
		label: "About"
	},
	{
		to: "/services",
		label: "Services"
	},
	{
		to: "/training",
		label: "Training"
	},
	{
		to: "/audits",
		label: "Audits"
	},
	{
		to: "/clients",
		label: "Clients"
	},
	{
		to: "/contact",
		label: "Contact"
	}
];
function Shell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:rounded-full focus:bg-surface focus:px-4 focus:py-2",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-ink text-on-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-6 gap-y-1 px-5 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-w-0 truncate",
							children: "Free consultation open until 10 Dec 2026"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/contact",
							search: { service: firm.offer },
							className: "inline-flex min-h-11 shrink-0 items-center gap-1 font-semibold",
							children: ["Book", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
								className: "size-4",
								"aria-hidden": true
							})]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "border-b border-line bg-bg/95 backdrop-blur-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: "flex min-w-0 items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: logo,
									alt: "",
									width: 44,
									height: 44,
									className: "size-11 shrink-0 rounded-full object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 leading-tight",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate font-display text-base font-semibold",
										children: "Shubhkiran"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-xs font-medium text-muted",
										children: "Quality Forum · Nashik"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
								className: "hidden items-center gap-1 lg:flex",
								"aria-label": "Primary",
								children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									to: item.to,
									className: `rounded-full px-3 py-2 text-sm font-semibold ${pathname === item.to ? "bg-ink text-on-ink" : "text-muted hover:text-ink"}`,
									current: pathname === item.to,
									children: item.label
								}, item.to))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/contact",
									className: "hidden min-h-11 items-center rounded-full bg-accent px-4 text-sm font-semibold text-on-accent sm:inline-flex",
									children: "Talk to SQF"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "inline-flex size-11 items-center justify-center rounded-full border border-line bg-surface lg:hidden",
									"aria-expanded": open,
									"aria-controls": "mobile-nav",
									onClick: () => setOpen((value) => !value),
									children: [open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: open ? "Close menu" : "Open menu"
									})]
								})]
							})
						]
					}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						id: "mobile-nav",
						className: "border-t border-line bg-bg px-5 py-2 lg:hidden",
						"aria-label": "Mobile",
						children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
							to: item.to,
							className: "block border-b border-line py-3 font-display text-2xl font-semibold",
							children: item.label
						}, item.to))
					}) : null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "main",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-8 bg-ink text-on-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: logo,
										alt: "",
										width: 48,
										height: 48,
										className: "size-12 rounded-full object-cover"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl font-semibold",
										children: firm.name
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 max-w-sm text-sm text-on-ink/80",
									children: [
										"Consultancy, training and audit readiness. Nashik, since ",
										firm.established,
										"."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-sm text-sm text-on-ink/80",
									children: firm.address
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-widest text-on-ink/60",
								children: "VISIT"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-3 space-y-2 text-sm",
								children: [nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									to: item.to,
									className: "hover:underline",
									children: item.label
								}) }, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: firm.profile,
									className: "hover:underline",
									children: "Company profile (PDF)"
								}) })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-widest text-on-ink/60",
								children: "TALK"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-3 space-y-2 text-sm",
								children: [
									firm.phones.map((phone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: `tel:${phone.tel}`,
										className: "hover:underline",
										children: [phone.display, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-on-ink/60",
											children: [" · ", phone.label]
										})]
									}) }, phone.tel)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: whatsappLink("Hello SQF, I would like to connect."),
										className: "hover:underline",
										children: ["WhatsApp · ", firm.whatsappDisplay]
									}) }),
									firm.emails.map((email) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: `mailto:${email}`,
										className: "hover:underline",
										children: email
									}) }, email))
								]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-on-ink/15",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-xs text-on-ink/70 md:flex-row md:items-center md:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"© ",
							(/* @__PURE__ */ new Date()).getFullYear(),
							" ",
							firm.name,
							". All rights reserved."
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-xl",
							children: disclaimer
						})]
					})
				})]
			})
		]
	});
}
function Kicker({ children, onDark = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `text-xs font-semibold tracking-widest uppercase ${onDark ? "text-on-ink/70" : "text-muted"}`,
		children
	});
}
function NavLink({ to, className, current, children }) {
	if (to === "/contact") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/contact",
		className,
		"aria-current": current ? "page" : void 0,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className,
		"aria-current": current ? "page" : void 0,
		children
	});
}
function PageIntro({ kicker, title, lede, actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mx-auto max-w-6xl px-5 pt-14 pb-10 md:pt-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: kicker }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 max-w-3xl font-display text-4xl font-semibold leading-tight sm:text-5xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-lg text-muted",
				children: lede
			}),
			actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex flex-wrap gap-3",
				children: actions
			}) : null
		]
	});
}
function ContactButton({ service = "", children, tone = "accent" }) {
	const className = `inline-flex min-h-11 items-center gap-2 rounded-full px-5 text-sm font-semibold ${tone === "ink" ? "bg-ink text-on-ink" : "bg-accent text-on-accent"}`;
	if (!service) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/contact",
		className,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
			className: "size-4",
			"aria-hidden": true
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/contact",
		search: { service },
		className,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
			className: "size-4",
			"aria-hidden": true
		})]
	});
}
function GhostLink({ href, children }) {
	const className = "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-5 text-sm font-semibold";
	if (href === "/contact") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/contact",
		className,
		children
	});
	if (href === "/services") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/services",
		className,
		children
	});
	if (href === "/" || href === "/about" || href === "/training" || href === "/audits" || href === "/clients") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: href,
		className,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		className,
		children
	});
}
function CloseBand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto max-w-6xl px-5 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6 rounded-card bg-surface p-8 ring-1 ring-line md:flex-row md:items-end md:justify-between md:p-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Next step" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mt-2 font-display text-3xl font-semibold leading-tight sm:text-4xl",
				children: ["Tell us the standard.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block",
					children: "We’ll talk through the scope."
				})]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactButton, { children: "Talk to SQF" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostLink, {
					href: whatsappLink("Hello SQF, I would like to connect."),
					children: "WhatsApp"
				})]
			})]
		})
	});
}
//#endregion
export { steps as C, why as E, standards as S, whatsappLink as T, interestOptions as _, PageIntro as a, sectors as b, achievements as c, auditCycle as d, clients as f, homeStats as g, gallery as h, Kicker as i, areas as l, firm as m, ContactButton as n, Shell as o, cycle as p, GhostLink as r, aboutStats as s, CloseBand as t, auditBenefits as u, logo as v, trainingTracks as w, services as x, pillars as y };
