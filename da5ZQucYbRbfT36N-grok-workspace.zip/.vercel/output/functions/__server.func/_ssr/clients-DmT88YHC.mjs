import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as ChevronRight, l as ChevronLeft, t as X } from "../_libs/lucide-react.mjs";
import { a as PageIntro, f as clients, h as gallery, i as Kicker, n as ContactButton, o as Shell, t as CloseBand } from "./shell-Bfw5R1rV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/clients-DmT88YHC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PhotoGrid() {
	const [index, setIndex] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (index === null) return;
		const onKey = (event) => {
			if (event.key === "Escape") setIndex(null);
			if (event.key === "ArrowRight") setIndex((i) => i === null ? i : (i + 1) % gallery.length);
			if (event.key === "ArrowLeft") setIndex((i) => i === null ? i : (i - 1 + gallery.length) % gallery.length);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [index]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
		children: gallery.map((photo, photoIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: photoIndex === 0 ? "sm:col-span-2 lg:col-span-2" : "",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "group block w-full overflow-hidden rounded-card bg-surface text-left ring-1 ring-line",
				onClick: () => setIndex(photoIndex),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: photo.src,
					alt: photo.alt,
					className: "aspect-[4/3] w-full object-cover motion-safe:transition motion-safe:group-hover:scale-105"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block px-4 py-3 text-sm font-semibold",
					children: photo.caption
				})]
			})
		}, photo.src))
	}), index !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-ink/90 p-4",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": gallery[index].caption,
		onClick: () => setIndex(null),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-4xl",
			onClick: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: gallery[index].src,
				alt: gallery[index].alt,
				className: "max-h-[75vh] w-full rounded-card object-contain"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between gap-3 text-on-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: gallery[index].caption
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center rounded-full bg-on-ink text-ink",
							"aria-label": "Previous photograph",
							onClick: () => setIndex((i) => i === null ? i : (i - 1 + gallery.length) % gallery.length),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center rounded-full bg-on-ink text-ink",
							"aria-label": "Next photograph",
							onClick: () => setIndex((i) => i === null ? i : (i + 1) % gallery.length),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center rounded-full bg-on-ink text-ink",
							"aria-label": "Close",
							onClick: () => setIndex(null),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})
					]
				})]
			})]
		})
	}) : null] });
}
function ClientsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			kicker: "Clients",
			title: "Shared experience. Lasting relationships.",
			lede: "Client references from the SQF company profile, and moments from the training community.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactButton, { children: "Work with SQF" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 pb-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Client references" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold",
					children: "Organizations featured in the profile."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted",
					children: "Named under “Key Client — Consulted Services”. The relationship is consultancy and training, not a claim that SQF certified these organizations."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5",
					children: clients.map((client) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex h-32 flex-col items-center justify-center gap-2 rounded-card bg-surface px-4 ring-1 ring-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: `/assets/images/clients/${client.file}`,
							alt: `${client.name} logo`,
							className: "max-h-12 w-full object-contain"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-center text-xs font-semibold text-muted",
							children: client.name
						})]
					}, client.file))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "mt-8 overflow-hidden rounded-card bg-surface ring-1 ring-line",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/assets/images/profile-client-panel.webp",
						alt: "Complete client reference panel from the SQF company profile, including all logos as supplied",
						className: "w-full object-contain"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "px-5 py-4 text-sm text-muted",
						children: "The complete panel from the company profile, including additional logo-only entries."
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "training-gallery",
			className: "mx-auto max-w-6xl px-5 pb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Training community" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold",
					children: "Learning together. Growing stronger."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 mb-6 text-muted",
					children: "Select a photograph to view it larger."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoGrid, {})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseBand, {})
	] });
}
//#endregion
export { ClientsPage as component };
