import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Phone, o as MapPin, s as Mail } from "../_libs/lucide-react.mjs";
import { T as whatsappLink, _ as interestOptions, i as Kicker, m as firm, o as Shell } from "./shell-Bfw5R1rV.mjs";
import { r as Route$2 } from "./router-DMcMyqK2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-BRVn7Ol0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EnquiryForm({ initialService = "" }) {
	const options = interestOptions.includes(initialService) || !initialService ? interestOptions : [initialService, ...interestOptions];
	const [service, setService] = (0, import_react.useState)(initialService || "ISO 9001");
	const [delivery, setDelivery] = (0, import_react.useState)("whatsapp");
	const [status, setStatus] = (0, import_react.useState)("");
	function onSubmit(event) {
		event.preventDefault();
		const data = new FormData(event.currentTarget);
		const name = String(data.get("name") ?? "").trim();
		const company = String(data.get("company") ?? "").trim();
		const message = String(data.get("message") ?? "").trim();
		const chosen = String(data.get("service") ?? service);
		const body = [
			"Hello SQF,",
			"",
			`Name: ${name}`,
			`Company: ${company}`,
			`Interested in: ${chosen}`,
			"",
			message
		].join("\n");
		if (delivery === "whatsapp") {
			const url = `https://wa.me/${firm.whatsapp}?text=${encodeURIComponent(body)}`;
			setStatus("Opening WhatsApp with your message. Nothing is stored on this website.");
			window.location.assign(url);
			return;
		}
		const url = `mailto:${firm.emails[0]}?subject=${encodeURIComponent(`SQF enquiry — ${chosen}`)}&body=${encodeURIComponent(body)}`;
		setStatus("Opening your email app with a prepared message. Nothing is stored on this website.");
		window.location.assign(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		id: "enquiry-form",
		onSubmit,
		className: "rounded-card bg-surface p-5 ring-1 ring-line sm:p-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-semibold",
				children: "How can we help?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Share a few details. You review and send the message yourself."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Your name",
						id: "name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "name",
							name: "name",
							required: true,
							autoComplete: "name",
							className: inputClass
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Company",
						id: "company",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "company",
							name: "company",
							required: true,
							autoComplete: "organization",
							className: inputClass
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "I’m interested in",
						id: "service",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "service",
							name: "service",
							value: service,
							onChange: (event) => setService(event.target.value),
							className: inputClass,
							children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: option,
								children: option
							}, option))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Your requirements",
						id: "message",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "message",
							name: "message",
							required: true,
							rows: 5,
							className: `${inputClass} h-auto py-3`
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-sm font-semibold",
					children: "Send using"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeliveryOption, {
						checked: delivery === "whatsapp",
						onChange: () => setDelivery("whatsapp"),
						label: "WhatsApp",
						value: "whatsapp"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeliveryOption, {
						checked: delivery === "email",
						onChange: () => setDelivery("email"),
						label: "Email",
						value: "email"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "mt-5 inline-flex min-h-12 w-full items-center justify-center rounded-full bg-accent px-5 font-semibold text-on-accent",
				children: delivery === "whatsapp" ? "Prepare WhatsApp enquiry" : "Prepare email enquiry"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				role: "status",
				children: status || (delivery === "whatsapp" ? "Opens WhatsApp with a prepared message. This website does not store your enquiry." : "Opens your email app with a prepared message. This website does not store your enquiry.")
			})
		]
	});
}
var inputClass = "h-12 w-full rounded-2xl border border-line bg-bg px-4 text-base outline-none";
function Field({ label, id, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-semibold",
		htmlFor: id,
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-2 block font-normal",
			children
		})]
	});
}
function DeliveryOption({ checked, onChange, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: `flex min-h-11 cursor-pointer items-center justify-center rounded-full border text-sm font-semibold ${checked ? "border-ink bg-ink text-on-ink" : "border-line bg-bg"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "sr-only",
			type: "radio",
			name: "delivery",
			value,
			checked,
			onChange
		}), label]
	});
}
function ContactPage() {
	const { service = "" } = Route$2.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid max-w-6xl gap-10 px-5 py-14 lg:grid-cols-2 lg:py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Let’s move forward" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl font-semibold leading-tight sm:text-5xl",
				children: "Your next step towards better."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-lg text-muted",
				children: "Tell us where you are and where you want to go. We’ll discuss the right consultancy, training, or audit-readiness support."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-8 space-y-3",
				children: [
					firm.phones.map((phone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `tel:${phone.tel}`,
						className: "flex min-h-14 items-center gap-3 rounded-card bg-surface px-4 ring-1 ring-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
							className: "size-5 text-accent",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: phone.display
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: phone.label
						})] })]
					}) }, phone.tel)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: whatsappLink("Hello SQF, I would like to discuss consultancy or training."),
						className: "flex min-h-14 items-center gap-3 rounded-card bg-surface px-4 ring-1 ring-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
							className: "size-5 text-accent",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block font-semibold",
							children: ["WhatsApp · ", firm.whatsappDisplay]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: "Start a chat"
						})] })]
					}) }),
					firm.emails.map((email) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `mailto:${email}`,
						className: "flex min-h-14 items-center gap-3 rounded-card bg-surface px-4 ring-1 ring-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
							className: "size-5 text-accent",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: email
						})]
					}) }, email)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: firm.map,
						className: "flex items-start gap-3 rounded-card bg-surface px-4 py-4 ring-1 ring-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
							className: "mt-0.5 size-5 shrink-0 text-accent",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: "Visit the office"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-muted",
							children: firm.address
						})] })]
					}) })
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnquiryForm, { initialService: service })]
	}) });
}
//#endregion
export { ContactPage as component };
