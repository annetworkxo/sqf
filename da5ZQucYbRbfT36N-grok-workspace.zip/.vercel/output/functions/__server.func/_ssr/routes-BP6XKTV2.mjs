import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Search, u as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { C as steps, S as standards, f as clients, g as homeStats, i as Kicker, m as firm, n as ContactButton, o as Shell, r as GhostLink, t as CloseBand, v as logo, y as pillars } from "./shell-Bfw5R1rV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BP6XKTV2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl items-center gap-10 px-5 pt-12 pb-8 lg:grid-cols-2 lg:pt-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Nashik, Maharashtra · Est. ", firm.established] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-4 font-display text-5xl font-semibold leading-none sm:text-6xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block",
							children: "Better systems."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block",
							children: "Stronger teams."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-accent",
							children: "Lasting quality."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-xl text-lg text-muted",
					children: firm.lede
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Finder, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactButton, { children: "Discuss your requirements" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostLink, {
						href: "/services",
						children: "Explore expertise"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 max-w-md text-sm text-muted",
					children: [
						"Consultancy. Training. Audit readiness.",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-ink",
							children: "A practical partner, from assessment to improvement."
						})
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "overflow-hidden rounded-card bg-surface ring-1 ring-line",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/assets/images/training-participants.webp",
					alt: "Training participants gathered for a group photograph with the SQF trainer",
					width: 1280,
					height: 960,
					className: "aspect-[4/3] w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
					className: "flex items-center justify-between gap-4 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-muted uppercase",
						children: "People at the heart of quality"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-xl font-semibold leading-tight",
						children: "Building capability. Creating lasting relationships."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: logo,
						alt: "",
						width: 48,
						height: 48,
						className: "size-12 shrink-0 rounded-full object-cover"
					})]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-wrap items-center gap-x-8 gap-y-4 px-5 py-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-muted uppercase",
					children: "Systems we support"
				}), standards.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/contact",
					search: { service: item.code },
					className: "min-h-11 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: item.code
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [" · ", item.label]
					})]
				}, item.code))]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl gap-8 px-5 py-16 md:grid-cols-2 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Your quality partner / since ", firm.established] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 font-display text-4xl font-semibold leading-tight",
				children: "Practical experience. Lasting relationships."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-lg text-muted",
				children: [
					"Based in Nashik and led by ",
					firm.leaderRole.toLowerCase(),
					" ",
					firm.leader,
					", SQF helps organizations strengthen systems, build capability, and prepare for third-party assessment."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/about",
				className: "mt-5 inline-flex min-h-11 items-center gap-1 font-semibold",
				children: ["Meet Shubhkiran Quality Forum", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
					className: "size-4",
					"aria-hidden": true
				})]
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-ink text-on-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16 md:py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-8 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-4xl font-semibold leading-tight",
							children: [
								"A complete management solution, since ",
								firm.established,
								"."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-on-ink/80",
							children: "SQF is a Nashik practice of auditors and engineers. The work is hands-on: management systems, the people who run them, and readiness for assessment — for organizations across India and those that operate further afield."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-10 grid gap-px overflow-hidden rounded-card bg-on-ink/15 sm:grid-cols-2 lg:grid-cols-5",
						children: homeStats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-ink p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-display text-4xl font-semibold",
								children: stat.value
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-2 text-sm text-on-ink/75",
								children: stat.label
							})]
						}, stat.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs text-on-ink/60",
						children: "Figures as presented in the SQF company profile. A certificate still depends on the scheme and the certification body."
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-16 md:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "How the work moves" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 max-w-xl font-display text-4xl font-semibold leading-tight",
					children: "From the requirement to a system that holds."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-muted",
					children: "Plant teams, quality heads, and suppliers usually need the same four things. SQF stays with the work, then leaves the knowledge with the people who will use it."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 grid gap-3 md:grid-cols-2 lg:grid-cols-4",
					children: steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-card bg-surface p-5 ring-1 ring-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-sm font-semibold text-accent",
								children: ["0", index + 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-display text-2xl font-semibold",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: step.body
							})
						]
					}, step.title))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 pb-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Explore SQF" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl font-semibold leading-tight",
					children: "Expertise for the next stage of growth."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostLink, {
					href: "/services",
					children: "Full catalogue"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-3 md:grid-cols-2",
				children: pillars.map((pillar, index) => {
					const className = "rounded-card bg-surface p-6 ring-1 ring-line hover:ring-ink";
					const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold text-accent",
							children: ["0", index + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 font-display text-2xl font-semibold",
							children: pillar.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: pillar.body
						})
					] });
					if (pillar.href === "/services") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/services",
						hash: "hash" in pillar ? pillar.hash : void 0,
						className,
						children: body
					}, pillar.title);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: pillar.href,
						className,
						children: body
					}, pillar.title);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl items-center gap-8 px-5 pb-16 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/assets/images/training-session.webp",
					alt: "SQF trainer presenting to participants at a workshop",
					className: "aspect-[3/4] w-full rounded-card object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/assets/images/learning-workshop.webp",
					alt: "Workshop participants facing a trainer and presentation screen",
					className: "mt-8 aspect-[3/4] w-full rounded-card object-cover"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "People at the heart of quality" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl font-semibold leading-tight",
					children: "Learn together. Improve together."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted",
					children: "Explore SQF’s training programmes, see moments from our workshops, and meet the organizations featured in the company profile."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostLink, {
						href: "/training",
						children: "Explore training"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostLink, {
						href: "/clients",
						children: "Clients & gallery"
					})]
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Key clients — consulted services" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-3xl font-semibold",
							children: "Beside operations that take quality seriously."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/clients",
							className: "inline-flex min-h-11 items-center font-semibold",
							children: "See the full list"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5",
						children: clients.slice(0, 10).map((client) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "flex h-24 items-center justify-center rounded-2xl bg-bg px-4 ring-1 ring-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: `/assets/images/clients/${client.file}`,
								alt: `${client.name} logo`,
								className: "max-h-12 w-full object-contain"
							})
						}, client.file))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs text-muted",
						children: "Logos identify organizations named in the company profile. The relationship is consultancy and training, not a certification claim."
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseBand, {})
	] });
}
function Finder() {
	const [query, setQuery] = (0, import_react.useState)("");
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-6 flex max-w-xl items-center gap-2 rounded-full border border-line bg-surface py-1 pr-1 pl-4",
		onSubmit: (event) => {
			event.preventDefault();
			navigate({
				to: "/services",
				search: query.trim() ? { q: query.trim() } : {}
			});
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: "size-4 shrink-0 text-muted",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "sr-only",
				htmlFor: "home-search",
				children: "Search standards and services"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "home-search",
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "Find a standard — ISO 9001, IATF, HACCP…",
				suppressHydrationWarning: true,
				className: "h-11 w-full bg-transparent text-base outline-none placeholder:text-muted"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "inline-flex h-11 shrink-0 items-center rounded-full bg-ink px-4 text-sm font-semibold text-on-ink",
				children: "Search"
			})
		]
	});
}
//#endregion
export { HomePage as component };
