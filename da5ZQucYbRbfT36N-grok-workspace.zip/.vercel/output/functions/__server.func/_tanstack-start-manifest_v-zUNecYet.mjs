//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-zUNecYet.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/audits",
			"/clients",
			"/contact",
			"/services",
			"/training"
		],
		preloads: [
			"/assets/index-BFwuIZtf.js",
			"/assets/createLucideIcon-DGh7nqS1.js",
			"/assets/preload-helper-D83gMg9A.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BFwuIZtf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BHfGDoS3.js",
			"/assets/useNavigate-RmSYguL5.js",
			"/assets/shell-CdBRWYyI.js",
			"/assets/search-BEtEI6Lw.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-CBYu35hW.js", "/assets/shell-CdBRWYyI.js"]
	},
	"/audits": {
		filePath: "/workspace/src/routes/audits.tsx",
		children: void 0,
		preloads: ["/assets/audits-I8RfXTzL.js", "/assets/shell-CdBRWYyI.js"]
	},
	"/clients": {
		filePath: "/workspace/src/routes/clients.tsx",
		children: void 0,
		preloads: ["/assets/clients-slMNL9CY.js", "/assets/shell-CdBRWYyI.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-AZM_rF-N.js", "/assets/shell-CdBRWYyI.js"]
	},
	"/services": {
		filePath: "/workspace/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-DR-nmZf3.js",
			"/assets/shell-CdBRWYyI.js",
			"/assets/search-BEtEI6Lw.js"
		]
	},
	"/training": {
		filePath: "/workspace/src/routes/training.tsx",
		children: void 0,
		preloads: ["/assets/training-xlFhQHjZ.js", "/assets/shell-CdBRWYyI.js"]
	}
} });
//#endregion
export { tsrStartManifest };
