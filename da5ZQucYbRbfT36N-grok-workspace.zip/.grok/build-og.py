#!/usr/bin/env python3
"""Compose the SQF share card from the official mark and workshop photos."""
from PIL import Image, ImageDraw, ImageFont, ImageFilter

NAVY = (16, 24, 43)
RED = (196, 22, 42)
CREAM = (243, 241, 236)
INK = (16, 24, 43)
MUTED = (92, 101, 120)
LINE = (228, 221, 210)
SURFACE = (255, 252, 248)

FONT = "/workspace/.grok/fonts"
W, H = 1200, 630

def font(name, size):
    return ImageFont.truetype(f"{FONT}/{name}.ttf", size)

def text_width(f, text, tracking=0):
    if not text:
        return 0
    return sum(f.getlength(ch) for ch in text) + tracking * (len(text) - 1)

def draw_tracked(draw, xy, text, f, fill, tracking=0, anchor="lt"):
    x, y = xy
    total = text_width(f, text, tracking)
    if anchor[0] == "m":
        x -= total / 2
    elif anchor[0] == "r":
        x -= total
    for ch in text:
        draw.text((x, y), ch, font=f, fill=fill)
        x += f.getlength(ch) + tracking
    return total

def cover(path, tw, th, focus=(0.5, 0.42)):
    im = Image.open(path).convert("RGB")
    sw, sh = im.size
    scale = max(tw / sw, th / sh)
    nw, nh = round(sw * scale), round(sh * scale)
    im = im.resize((nw, nh), Image.Resampling.LANCZOS)
    cx, cy = focus[0] * nw, focus[1] * nh
    left = max(0, min(nw - tw, round(cx - tw / 2)))
    top = max(0, min(nh - th, round(cy - th / 2)))
    return im.crop((left, top, left + tw, top + th))

def paste_round(base, im, xy, radius):
    w, h = im.size
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, w - 1, h - 1), radius=radius, fill=255)
    # feather the mask edge a hair so JPEG doesn't stair-step
    base.paste(im, xy, mask)
    return mask

def main():
    canvas = Image.new("RGB", (W, H), CREAM)
    draw = ImageDraw.Draw(canvas)

    # Photo mosaic — official workshop photographs only.
    radius = 18
    gap = 12
    px0, py0 = 492, 28
    pw, ph = W - px0 - 28, H - 56  # 680 x 574
    hero_h = 358
    bot_h = ph - hero_h - gap
    bot_w = (pw - gap) // 2

    hero = cover(
        "/workspace/public/assets/images/professional-training-group.webp",
        pw,
        hero_h,
        focus=(0.50, 0.46),
    )
    session = cover(
        "/workspace/public/assets/images/training-session.webp",
        bot_w,
        bot_h,
        focus=(0.52, 0.42),
    )
    ceremony = cover(
        "/workspace/public/assets/images/recognition-ceremony.webp",
        bot_w,
        bot_h,
        focus=(0.52, 0.50),
    )
    paste_round(canvas, hero, (px0, py0), radius)
    paste_round(canvas, session, (px0, py0 + hero_h + gap), radius)
    paste_round(canvas, ceremony, (px0 + bot_w + gap, py0 + hero_h + gap), radius)

    # hairline rings in the site's line color
    ring = LINE
    boxes = [
        (px0, py0, pw, hero_h),
        (px0, py0 + hero_h + gap, bot_w, bot_h),
        (px0 + bot_w + gap, py0 + hero_h + gap, bot_w, bot_h),
    ]
    for x, y, w, h in boxes:
        draw.rounded_rectangle((x, y, x + w - 1, y + h - 1), radius=radius, outline=ring, width=2)

    # Left lockup
    logo = Image.open("/workspace/public/assets/images/sqf-logo-mark.png").convert("RGBA")
    logo_s = 132
    logo = logo.resize((logo_s, logo_s), Image.Resampling.LANCZOS)

    f_kick = font("Outfit-600", 15)
    f_title = font("Outfit-700", 52)
    f_sub = font("Outfit-600", 24)
    f_tag = font("Manrope-600", 20)

    title = "SHUBHKIRAN"
    sub = "QUALITY FORUM"
    kick = "NASHIK  ·  SINCE 1999"
    line1 = "Better systems. Stronger teams."
    line2 = "Lasting quality."

    title_w = text_width(f_title, title, tracking=0.4)
    sub_w = text_width(f_sub, sub, tracking=2.4)
    kick_w = text_width(f_kick, kick, tracking=1.6)
    # ascent estimates from font size
    block_h = logo_s + 20 + 18 + 16 + 56 + 6 + 30 + 18 + 5 + 16 + 26 + 4 + 26
    top = (H - block_h) // 2
    left = 44

    # circular crop is already the mark; drop it straight on cream
    canvas.paste(logo, (left, top), logo)

    y = top + logo_s + 20
    draw_tracked(draw, (left, y), kick, f_kick, MUTED, tracking=1.6)
    y += 18 + 16
    draw_tracked(draw, (left, y), title, f_title, INK, tracking=0.4)
    y += 56
    draw_tracked(draw, (left, y), sub, f_sub, INK, tracking=2.4)
    y += 30 + 16
    rule_w = 72
    draw.rounded_rectangle((left, y, left + rule_w, y + 5), radius=2, fill=RED)
    y += 5 + 16
    draw.text((left, y), line1, font=f_tag, fill=INK)
    y += 26 + 2
    draw.text((left, y), line2, font=f_tag, fill=RED)

    canvas.save("/workspace/.grok/og-preview.png", "PNG")
    print("preview", canvas.size)
    print("title_w", title_w, "sub_w", sub_w, "kick_w", kick_w, "top", top, "block", block_h)

if __name__ == "__main__":
    main()
